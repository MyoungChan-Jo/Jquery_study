$(document).ready(function(){
    //상단 고정메뉴
    $(window).scroll(function(){
        if($(this).scrollTop()>40){
            $("#main_navi_wrap").addClass("fixed1");
        }else{
            $("#main_navi_wrap").removeClass("fixed1");
        }
    });
    
    //.top_btn
    
    $(".top_btn").click(function(){
        //$("html,body").stop().animate({scrollTop:0},0);
        $("html,body").stop().animate({scrollTop:0},2000,"easeInBounce");
    });
    
    
    
    
    
    
    
    
    
    
    
    
});