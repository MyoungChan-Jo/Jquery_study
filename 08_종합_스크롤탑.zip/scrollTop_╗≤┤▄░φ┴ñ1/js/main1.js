$(document).ready(function(){
	//상단 고정 메뉴
});//end