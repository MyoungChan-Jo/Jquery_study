$(document).ready(function(){

    $(".fillCircle1").text("");
    $(".fillCircle2").text("");
    $(".fillCircle3").text("");
    $(".fillCircle4").text("");
    $(".fillCircle5").text("");
}); // end