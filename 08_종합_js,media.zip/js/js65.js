$(document).ready(function(){
    //counter_all
    
    /*
    $(selector).animate({styles},{options})
    options -
        duration : 속도,지속시간
        complete : 애니메이션 완료 후 실행할 함수 지정
        step : 애니메이션의 각 단계에 대해 실행할 함수
    */
    
    $(".counter_wrap li .counter").css("opacity","0"); //span
    $(".counter_wrap li .counter").animate({"opacity":"1"});
    $(".counter").each(function(){
        var $this = $(this), countTo = $this.attr("data-count");
        $({countNum:$this.text()}).animate({
            //style
            countNum : countTo
        },
        {
            //option
            duration : 4500, //지속시간,속도
            easing : "linear", //효과(일정)
            step : function(){ //애니메이션의 각 단계
                $this.text(Math.floor(this.countNum)); //내림
            },
            complete : function(){
                $this.text(this.countNum); //애니메이션 완료 후 실행
            }
        });
    });
    
    
    
    
    
    
    
    
    
    
    
});