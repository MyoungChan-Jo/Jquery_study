$(document).ready(function(){
    //wrap
    var i = 0;
    //console.log(num); 9
    $(".b_left").click(function(){//<
        if(i>0){ //i가 0초과
            i--;
            var move = -678*i;
            $("#photo").stop().animate({left:move},500);
        }else{
            alert("end_left");
        }
    });
    
    $(".b_right").click(function(){//>
        if(i<2){ //i가 (9-3)미만이면,
            i++;
            var move = -678*i;
            $("#photo").stop().animate({left:move},500);
        }else{
            alert("end_right");
        }
    });
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
});