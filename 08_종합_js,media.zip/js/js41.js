$(document).ready(function(){
    //$(selector).each selector에 각각 순차적으로 명령
    
    //wrap
    
    $(".btn").click(function(){
        $(".ex_t").each(function(index){
            //console.log(index); 0 1 2 3 4
            $(this).delay(index*200)
                .animate({left:"400px"},1000,"easeOutQuint")
                .animate({left:"0"},1000,"easeOutQuint");
        });
    });
    
    //wrap1
    //버튼을 클릭하면 li의 텍스트를 순차적으로 alert 띄우기
    
    $(".btn1").click(function(){
        $(".list1 li").each(function(){
            alert($(this).text());
        });
    });
    
    //wrap2
    //li의 텍스트를 li의 글자색으로 적용
    
    $(".color2 li").each(function(){
        $(this).css("color",$(this).text());
    });
    
    //wrap3
    //div의 추가된 속성값을 div의 배경색으로 적용
    
    $("#wrap3 div").text("");
    $("#wrap3 div").each(function(){
        var bg1 = $(this).attr("data-bg");
        $(this).css("background-color",bg1);
    });
    
    //wrap4
    
    function wrap4(){
        var text4 = $(".wrap4_t").val();
        $(".txt4").each(function(){
            $(this).val(text4);
        });
    }
    
    $(".wrap4_t").keyup(wrap4);
    
    //wrap5
    
    function wrap5(){
        var text5 = $(".wrap5_t").val();
        $(".txt5").each(function(){
            $(this).val(index+" - "+text5);
        });
    }
    
    $(".wrap5_t").keyup(wrap5);
    
    //wrap6
    
    $(".btn6_1").click(function(){
        $(".txt6").each(function(n){
            //console.log(n); 0 1 2 3 4
            var text6 = this;
            setTimeout(function(){
                $(text6).css("background-color","pink");
            },n*1000); //1초 간격으로 배경색
        });
    });
    
    $(".btn6_2").click(function(){
        $(".txt6").css("background-color","");
    });
    
    //wrap7
    
    $(".btn7_1").click(function(){
        $(".txt7").each(function(k){
            var text7 = this;
            if(k>2) return false; //실행멈추기 0 1 2 => 3개실행
            setTimeout(function(){
                $(text7).css("background-color","orange");
            },k*1000); //1초 간격으로 배경색
        });
    });
    
    $(".btn7_2").click(function(){
        $(".txt7").css("background-color","");
    });
    
    //wrap8
    
    function wrap8(){
        var text8 = "";
        $("#wrap8 [name='chk8']:checked").each(function(){
            text8 += $(this).val()+'\n';
        });
        $(".txt8").val(text8);
    }
    
    $("#wrap8 [name='chk8']").bind("click",wrap8); //체크박스에 클릭이벤트 지정
    
    //wrap9
    
    var order1 = $("#order1 .order_t"),
        order2 = $("#order2 .order_t");
    
    $("#chk_all").change(function(){
        var checked1 = $(this).prop("checked");; // true, false
        if(checked1==true){ //if(checked1)
            order2.each(function(i){
                var value1 = order1[i].value;
                $(this).val(value1);
            });
        }else{
           order2.val("");
        }
    });
    
    //wrap10
    //$(selector).end() 마지막에 적용된 필터링을 끝내고 처음부터 다시 시작하여 대상에 명령, 최근 필터링을 끝내고 처음부터 다시
    
    $(".btn10_1").click(function(){
        $("#wrap10").find(".txt10_1").addClass("sel"); // 1 4 6
    });
    $(".btn10_2").click(function(){
        $("#wrap10").find(".txt10_2").addClass("sel"); // 2 3 5
    });
    $(".btn10_3").click(function(){
        $("#wrap10").find(".txt10_1").addClass("sel")
        .find(".txt10_2").addClass("sel"); // 1 4 6
    });
    $(".btn10_4").click(function(){
        $("#wrap10").find(".txt10_1").addClass("sel").end()
        .find(".txt10_2").addClass("sel"); // 1 2 3 4 5 6
    });
    $(".btn10_5").click(function(){
        $("#wrap10").find(".txt10_1, .txt10_2").addClass("sel"); // 1 2 3 4 5 6
    });
    $(".btn10_6").click(function(){
        $("#wrap10 span").removeClass("sel");
    });
    
    //wrap11
    //$(selector).is() selector의 대상을 비교하여 맞으면 true 아니면 false를 반환
    $("#wrap11 span").click(function(){
        if($(this).is("[class='txt11']")){ //클릭한 span에 class가 txt11이면 배경색, 아니면 보더색
            $(this).css("background-color","purple"); // 1 2 4 6
        }else{
            $(this).css("border-color","red"); // 3 5
        }
    });
    
    
    
    
    
    
    
    
    
    
});