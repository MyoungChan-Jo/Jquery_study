$(document).ready(function(){
    //faq
    //첫번째 dd제외한 나머지 dd 숨기기
    $("#faq dd:not(:first)").css("display","none");
    
    $("#faq dt:first").find(">span").css({"transform":"rotate(180deg)","color":"#333333","border-color":"#333333"});
    
    $("#faq dt").click(function(){
        if($(this).find("+dd").css("display")=="none"){//클릭한 태그 다음(뒤)에 있는 dd태그의 속성이 none이면
            $("#faq dd").slideUp("fast");
            $(this).find("+dd").slideDown("fast");
            
           $("#faq dt").find(">span").css({transform:"rotate(0deg)","color":"#eaeaea","border-color":"#eaeaea"}); $(this).find(">span").css({transform:"rotate(180deg)","color":"#333333","border-color":"#333333"});
        }
    });
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
});