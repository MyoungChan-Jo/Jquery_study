$(document).ready(function(){
    //wrap
    
    var n = 1;
    $(".btn").click(function(){
        n = $(this).attr("data-n");
        $(".btn_wrap button").removeClass("active");
        $(".btn"+n).addClass("active");
        $(".photo li").css({left:0}).stop().animate({left:"-1024px"});
        $(".photo li.no"+n).css({left:"1024px"}).stop().animate({left:0});
    });
    
    $(".prev").click(function(){ //<
        n--; //클릭하면 0부터 시작
        if(n==0){
            n = 5;
        }
        $(".photo li").css({left:0}).stop().animate({left:"-1024px"});
        $(".photo li.no"+n).css({left:"1024px"}).stop().animate({left:0});
        $(".btn_wrap button").removeClass("active");
        $(".btn"+n).addClass("active");
        //console.log(n); 5 4 3 2 1 5 ..
    });
    
    $(".next").click(function(){ //>
        n++; //클릭하면 2부터 시작
        if(n==6){
            n = 1;
        }
        $(".photo li").css({left:0}).stop().animate({left:"-1024px"});
        $(".photo li.no"+n).css({left:"1024px"}).stop().animate({left:0});
        $(".btn_wrap button").removeClass("active");
        $(".btn"+n).addClass("active");
        //console.log(n); 2 3 4 5 2 ..
        
    });
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
});