$(document).ready(function(){
	
	var page = 1;
	$(window).mousewheel(function(){
		return false; // 기본 휠 기능 제거.
	});
	
	// 마우스 휠
	$(".box").mousewheel(function(e,delta){
		page = $(this).attr("data-n") - delta;
		var target = $(".box" + page).offset().top;
		$("body, html").stop().animate({"scrollTop" : target});
	}); 
	
	// 스크롤
	$(window).scroll(function(){
		var offset1 = $(".box1").offset().top;
		var offset2 = $(".box2").offset().top;
		var offset3 = $(".box3").offset().top;
		var offset4 = $(".box4").offset().top;
		var offset5 = $(".box5").offset().top;
		
		var st = $(window).scrollTop();
		//공통부분 작업
		$(".#gnb ul li a").removeClass("sel1");
		$(".circle").removeClass("sel2");
		
		if(st < offset2){ //1페이지 일때
			$(".menu1").addClass("sel1");
			$(".circle1").addClass("sel2");
			page = 1;
		}else if(st >= offset2 && st < offset3){//2페이지 일때
			$(".menu2").addClass("sel1");
			$(".circle2").addClass("sel2");
			page = 2;
		}else if(st >= offset3 && st < offset4){//3페이지 일때
			$(".menu3").addClass("sel1");
			$(".circle3").addClass("sel2");
			page = 3; 
		}else if(st >= offset4 && st < offset5){//4페이지 일때
			$(".menu4").addClass("sel1");
			$(".circle4").addClass("sel2");
			page = 4;	 
		}else{
			$(".menu5").addClass("sel1");
			$(".circle5").addClass("sel2");
			page = 5;
		}
		return false;
	});
	
	//클릭할때
	$("#gnb ul li a, .circle").click(function(){
		page = $(this).attr("data-n");
		target = $(".box"+page).offset().top;
		$("body,html").stop().animate({"scrollTop" : target});
	});
	
	
	
});//end