$(document).ready(function(){
    //wrap
    
    var i = 0;
    var auto = setInterval(function(){
        i++;
        if(i<3){
            $("#img_wrap img").css({left:0}).stop().animate({left:"-100%"});
            $("#img_wrap img").eq(i).css({left:"100%"}).stop().animate({left:0});
            $("#btn p").removeClass("on");
            $("#btn p").eq(i).addClass("on");
            //console.log(i) 1 2
        }else{
            i = 0;
            $("#img_wrap img").css({left:0}).stop().animate({left:"-100%"});
            $("#img_wrap img").eq(i).css({left:"100%"}).stop().animate({left:0});
            $("#btn p").removeClass("on");
            $("#btn p").eq(i).addClass("on");
        }
    },3000);
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
});