$(document).ready(function(){
    //top
    
    $("#top").before("<p class='txt'>0</p>");
    $(".txt").css({"position":"fixed","right":"50px","top":"0","color":"black","margin":"0","padding":"0"});
    
    $("#con1 ul li").fadeOut();
    $("#con2 ul li").hide();
    $("#con3 ul li").css("opacity","0");
    
    $(window).scroll(function(){
        $(".txt").text($(this).scrollTop());
        if($(this).scrollTop()>400){
            $("#con1 ul li").eq(0).delay(0).fadeIn();
            $("#con1 ul li").eq(1).delay(500).fadeIn();
            $("#con1 ul li").eq(2).delay(1000).fadeIn();
            $("#con1 ul li").eq(3).delay(1500).fadeIn();
            $(".txt").css("color","blue");
        }
        
        if($(this).scrollTop()>1000){
            $("#con2 ul li:eq(0)").delay(0).slideDown();
            $("#con2 ul li:eq(1)").delay(500).slideDown();
            $("#con2 ul li:eq(2)").delay(1000).slideDown();
            $("#con2 ul li:eq(3)").delay(1500).slideDown();
            $(".txt").css("color","white");
        }
        
        if($(this).scrollTop()>1600){
            $(".con3_1").animate({"opacity":"1"});
            $(".txt").css("color","pink");
        }
        if($(this).scrollTop()>1900){
            $(".con3_2").animate({"opacity":"1"});
            $(".txt").css("color","pink");
        }
        if($(this).scrollTop()>2200){
            $(".con3_3").animate({"opacity":"1"});
            $(".txt").css("color","pink");
        }
        if($(this).scrollTop()>2500){
            $(".con3_4").animate({"opacity":"1"});
            $(".txt").css("color","pink");
        }
    });
    
    
    
    
    
    
});