$(document).ready(function(){
    //wrap
    var i = 0;
    var num = $("#photo img").length; //개수 .size()
    //console.log(num); 9
    $(".b_left").click(function(){//<
        if(i>0){ //i가 0초과
            i--;
            var move = -226*i;
            //console.log(i); 5 4 3 2 1 0
            $("#photo").stop().animate({left:move},500);
        }else{
            alert("end_left");
        }
    });
    
    $(".b_right").click(function(){//>
        if(i<num-3){ //i가 (9-3)미만이면,
            i++;
            var move = -226*i;
            //console.log(i); 1 2 3 4 5 6
            $("#photo").stop().animate({left:move},500);
        }else{
            alert("end_right");
        }
    });
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
});