function main_img(){
    $("#main_img").animate({
        marginTop : parseInt($("#main_img").css("margin-top"))-500+"px"
    },"slow",function(){
        $("#main_img p:first").appendTo("#main_img");
        $("#main_img").css("margin-top","-500px");
    });
}

$(document).ready(function(){
    //main_wrap
    
    var height1 = 500 * $("#main_img p").size()+"px";
    $("#main_img").css("height",height1);
    //alert(height1); 
    $("#main_img p:last").prependTo("#main_img");
    $("#main_img").css("margin-top","-500px");
    
    var timer = setInterval("main_img()",2000);
    
    $("#main_img").hover(function(){
        clearInterval(timer);
    }).mouseout(function(){
        timer = setInterval("main_img()",2000);
    });
    
    
    
    
    
    
    
    
    
    
    
    
    
    
});