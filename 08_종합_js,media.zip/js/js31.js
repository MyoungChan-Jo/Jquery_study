$(document).ready(function(){
    //banner_wrap
    
    var visual = $("#banner_img > ul > li"); //슬라이더 대상 이미지

    var button = $("#btn_wrap > li"); //버튼

    var current = 0;

    var setIntervalId;


    button.on({

    click:function(){

    var tg = $(this);

    var i = tg.index(); //0부터 시작, 없으면 -1반환


    button.removeClass('on');

    tg.addClass('on');


    move(i);

    }

    });


    $("#banner_wrap").on({ //전체영역

    mouseover:function(){

    clearInterval(setIntervalId); //clearInterval -> setInterval 중지

    }, //clearTimeOut() -> timer 중지

    mouseout:function(){

    timer();

    }

    });


    timer();

    function timer(){

    setIntervalId = setInterval(function(){

    var n = current + 1;

    if(n == visual.size()){ //li 개수

    n = 0;

    }


    button.eq(n).click();

    }, 5000);

    }


    function move(i){

    if(current == i) return;


    var currentEl = visual.eq(current);

    var nextEl = visual.eq(i);


    currentEl.css({left:0}).stop().animate({left:'-100%'});

    nextEl.css({left:'100%'}).stop().animate({left:0});


    current = i;

    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
});