$(document).ready(function(){
    //top
    //우측상단 아이콘 변경
    $("#top > ul > li").hover(function(){
        //$(selector).children() selector의 직접적인 자식요소
        var i_src = $(this).children(".s_img").attr("data-src");
        $(this).children(".s_img").attr("src",i_src);
    },function(){
        $(".s_img:eq(0)").attr("src","images/btn_search_off.png");
        $(".s_img:eq(1)").attr("src","images/btn_careers_off.png");
        $(".s_img:eq(2)").attr("src","images/btn_language_off.png");
    });
    
    //통합검색
    $("#top > ul > li.search > div").hide();
    $("#top > ul > li.search").mouseover(function(){
        $("#top > ul > li.search > div").stop().slideDown("fast","easeOutBounce");
    }).mouseout(function(){
        $("#top > ul > li.search > div").stop().slideUp(400,"easeOutBounce");
    });
    
    //language
    $("#top > ul > li.language > ul").hide();
    $("#top > ul > li.language").mouseover(function(){
        $(this).children("ul").stop().fadeIn();
    }).mouseout(function(){
        $(this).children("ul").stop().fadeOut();
    });
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
});