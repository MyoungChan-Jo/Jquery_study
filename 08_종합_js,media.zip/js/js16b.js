$(document).ready(function(){
    //menu_wrap
    //left_navi 좌측메뉴
    $("#navi .main:first").addClass("sel");
    $("#navi .submenu:not(:first)").hide();
    $("#navi .main").click(function(){
        $("#navi .main").removeClass("sel");
        $(this).addClass("sel");
        if($(this).next().css("display")=="none"){
            $("#navi .submenu").slideUp("fast");
        }
        $(this).next().slideDown("fast");//.submenu
    });
    
    //container 우측내용 변경
    $("#container section:not("+$(".submenu li a.selected1").attr("href")+")").hide();
    $(".submenu li a").click(function(){
        $(".submenu li a").removeClass("selected1");
        $(this).addClass("selected1");
        $("#container section").hide();
        $($(this).attr("href")).show();
        return false;
    });
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
});