$(document).ready(function(){
    //우측상단 임시 출력
    $("#main_menu").before("<p class='txt'>0</p>");
    $(".txt").css({"position":"fixed","top":"10px","right":"10px","color":"#ffffff","z-index":100});
    
    //intro
    
    setTimeout(function(){
        $("#intro h1").animate({"top":"40%","opacity":"1"});
    },200);
    setTimeout(function(){
        $("#intro p").animate({"bottom":"50%","opacity":"1"});
    },400);
    setTimeout(function(){
        $(".no1").animate({"opacity":"1"});
    },800);
    
    
    $(window).scroll(function(){
        $(".txt").text($(window).scrollTop()); //우측상단 임시 출력
        
        $("#main_menu ul li a").removeClass("on");
        $(".btn").removeClass("sel");
        
        var con1 = $(".con1").offset().top;
        var con2 = $(".con2").offset().top;
        var con3 = $(".con3").offset().top;
        var con4 = $(".con4").offset().top;
        var con5 = $(".con5").offset().top;
        
        var scroll = $(window).scrollTop();
        
        if(scroll < con2){ //1page
            $("#main_menu ul li a:eq(0)").addClass("on");
            $(".btn1").addClass("sel");
            k = 1;
        }else if(scroll >= con2 && scroll < con3){ //2page
            $("#main_menu ul li a:eq(1)").addClass("on");
            $(".btn2").addClass("sel");
            k = 2;
            
            $("#about_bg div:eq(0)").animate({"opacity":"1","right":"50%"},500);
        }else if(scroll >= con3 && scroll < con4){ //3page
            $("#main_menu ul li a:eq(2)").addClass("on");
            $(".btn3").addClass("sel");
            k = 3;
            
            $("#project_bg div:eq(0)").animate({"opacity":"1","left":"50%"},500);
        }else if(scroll >= con4 && scroll < con5){ //4page
            $("#main_menu ul li a:eq(3)").addClass("on");
            $(".btn4").addClass("sel");
            k = 4;
            
            $("#portfolio li:eq(0)").delay(100).animate({"opacity":"1"},500);
            $("#portfolio li:eq(1)").delay(500).animate({"opacity":"1"},500);
            $("#portfolio li:eq(2)").delay(1000).animate({"opacity":"1"},500);
            $("#portfolio li:eq(3)").delay(1500).animate({"opacity":"1"},500);
            $("#portfolio li:eq(4)").delay(2000).animate({"opacity":"1"},500);
            $("#portfolio li:eq(5)").delay(2500).animate({"opacity":"1"},500);
        }else{ //5page
            $("#main_menu ul li a:eq(4)").addClass("on");
            $(".btn5").addClass("sel");
            k = 5;
            
            $("#contact_bg div:eq(0)").animate({"opacity":"1","top":"50%"},500);
        }
        return false;
    });
    
    //↓ 애니메이션
    
    var btn = setInterval(function(){
        $(".no").animate({"bottom":"80px"},1000);
        $(".no").animate({"bottom":"100px"},1000);
    },1000);
    
    //마우스 휠
    
    var k = 1;
    $(window).mousewheel(function(){
        return false; //기본 휠 기능 제어
    });
    
    $(".contents").mousewheel(function(e,delta){
        k = $(this).attr("data-n") - delta;
        var target = $(".con"+k).offset().top;
        $("body,html").stop().animate({"scrollTop":target});
        return false; //기본 휠 기능 제어
    });
    
    //main_menu, btn(●)
    
    $("#main_menu ul li a, .btn").click(function(){
        k = $(this).attr("data-n");
        target = $(".con"+k).offset().top;
        $("body,html").stop().animate({"scrollTop":target});
        return false;
    });
    
    //↓ 이동
    
    var h = $(window).height();
    $(".no1").click(function(){
        $("html").stop().animate({"scrollTop":h},500);
    });
    $(".no2").click(function(){
        $("html").stop().animate({"scrollTop":h*2},500);
    });
    $(".no3").click(function(){
        $("html").stop().animate({"scrollTop":h*3},500);
    });
    $(".no4").click(function(){
        $("html").stop().animate({"scrollTop":h*4},500);
    });
    
    
    
    
    
    
});