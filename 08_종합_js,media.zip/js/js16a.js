$(document).ready(function(){
    //menu1
    $("#menu1 > ul > li > ul:not(:first)").hide();//첫번째 .submenu제외한 나머지 숨김
    $("#menu1 > ul > li > a:first").addClass("sel1");//메뉴1
    $("#menu1 > ul > li > a").click(function(){
        $("#menu1 > ul > li > a").removeClass("sel1");
        $(this).addClass("sel1");
        //$("#menu1 > ul > li > a").siblings().slideUp();
        $(this).siblings().slideDown(); //해당 selctor제외한 모든 형제 .submenu
        $(this).parent().siblings().children(".submenu").slideUp(); //부모에서 해당 selector제외한 형제의 자식요소 .submenu
        return false;
    });
    
    //menu2
    $("#menu2 > ul > li > ul:not(:first)").hide();//첫번째 .submenu제외한 나머지 숨김
    $("#menu2 > ul > li > a:first").addClass("sel2");//메뉴1
    $("#menu2 > ul > li > a").click(function(){
        $("#menu2 > ul > li > a").removeClass("sel2");
        $(this).addClass("sel2");
        if($(this).next().css("display")=="none"){//.sub
            $("#menu2 > ul > li > .sub").slideUp();
        }
        var n2 = $(this).attr("data-menu");
        $("#menu2 > ul > li > .sub"+n2).slideDown();
    });
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
});