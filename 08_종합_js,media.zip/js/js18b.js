$(document).ready(function(){
    //join_wrap
    
    $(".join li a").click(function(){
        return false;
    });
    
    $(".btn_prev").css("opacity","0.5");//이전버튼
    var i = 0;
    $(".btn_next").click(function(){//다음버튼
        $(".btn_prev").css("opacity","1");
        if(i<3){
            i++;//1씩 더하기
            var move = -600*i
            $("#join_con").stop().animate({left:move},500);
            var n = 1;
            var k = n+i;
            //alert(k);
            $(".join li a").removeClass("j_sel");
            $(".join .join" + k + " a").addClass("j_sel");//.join .join2 a ~ .join .join4 a
        }else{
            alert("마지막 페이지입니다.");
            $(".btn_next").css("opacity","0.5");
        }
    });
    
    $(".btn_prev").click(function(){//이전버튼
        $(".btn_next").css("opacity","1");
        if(i>0){//0초과
            i--;
            var move = -600*i;
            $("#join_con").stop().animate({left:move},500);
            var n = 1;
            var k = n+i;
            //alert(k);
            $(".join li a").removeClass("j_sel");
            $(".join .join" + k + " a").addClass("j_sel");//.join .join2 a ~ .join .join4 a
        }else{
            alert("첫 페이지입니다.");
            $(".btn_prev").css("opacity","0.5");
        }
            
    });
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
});