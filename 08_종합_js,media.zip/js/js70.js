$(document).ready(function(){
	//우측상단임시출력
	$("#main_menu").before("<p class='txt'>0</p>")
	$(".txt").css({"position":"fixed","top":"15px","right":"15px","color":"red","z-index":"100","fontSize":"30px"});
	
	// 화살표 애니메이션 1500m/s 간격으로 반복하시오. 
	var btn = setInterval(function(){
		$(".no").animate({"bottom":"80px"},1200);
		$(".no").animate({"bottom":"100px"},1200);
	},1500);
	
	//휠기능 제거
	var k = 1;
	$(window).mousewheel(function(){ 
		return false;
	});
	
	//마우스 휠
	$(".contents").mousewheel(function(e,delta){
		k = $(this).attr("data-n") - delta;
		var target = $(".con" + k).offset().top;
		$("body,html").stop().animate({"scrollTop" : target});
		return false;
	});
	
	//상단메뉴 & 우측 ●
	$("#main_menu ul li a, .btn").click(function(){
		k = $(this).attr("data-n");
		var target = $(".con"+k).offset().top;
		$("body,html").stop().animate({"scrollTop" : target});
		return false;
	});
	
	//INTRO
	setTimeout(function(){
		$("#intro h1").animate({"top":"40%","opacity":"1"});
	},300);
	setTimeout(function(){
		$("#intro p").animate({"bottom":"50%","opacity":"1"});
	},600);
	setTimeout(function(){
		$(".no1").animate({opacity:"1"});
	},1000);
	
	//ABOUT ME
	setTimeout(function(){})
	
	
	
	
	
	//스크롤 값 출력
	$(window).scroll(function(){
		$(".txt").text($(window).scrollTop());
		//스크롤이 들어가면 해당 부분에 클래스 추가/제거
		$("#main_menu ul li a").removeClass("on"); /*공통*/
		$(".btn").removeClass("sel");/*공통*/
		
		var con1 = $(".con1").offset().top;
		var con2 = $(".con2").offset().top;
		var con3 = $(".con3").offset().top;
		var con4 = $(".con4").offset().top;
		var con5 = $(".con5").offset().top;
		
		var scroll = $(window).scrollTop();
		if(scroll < con2){/*1page*/
		    $("#main_menu ul li a:eq(0)").addClass("on");
			$(".btn1").addClass("sel");
			k=1;
		}else if(scroll >= con2 && scroll < con3){/*2page*/
			$("#main_menu ul li a:eq(1)").addClass("on");
			$(".btn2").addClass("sel");
			k=2;
			//숨긴 내용 보이게 만들기. ▽
			$("#about_bg div:eq(0)").animate({"opacity":"1","right":"50%"},500);
		}else if(scroll >= con3 && scroll < con4){/*3page*/
			$("#main_menu ul li a:eq(2)").addClass("on");
			$(".btn3").addClass("sel");
			k=3;
			//숨긴 내용 보이게 만들기. ▽
			$("#project_bg div:eq(0)").animate({"opacity":"1","left":"50%"},500);
		}else if(scroll >= con4 && scroll < con5){/*4page*/
			$("#main_menu ul li a:eq(3)").addClass("on");
			$(".btn4").addClass("sel");
			k=4;
			//숨긴 내용 보이게 만들기. ▽
			$("#portpolio li:eq(0)").delay(100).animate({"opacity":"1"},500)
			$("#portpolio li:eq(1)").delay(500).animate({"opacity":"1"},500)
			$("#portpolio li:eq(2)").delay(1000).animate({"opacity":"1"},500)
			$("#portpolio li:eq(3)").delay(1500).animate({"opacity":"1"},500)
			$("#portpolio li:eq(4)").delay(2000).animate({"opacity":"1"},500)
			$("#portpolio li:eq(5)").delay(2500).animate({"opacity":"1"},500)
		}else{/*5page*/
			$("#main_menu ul li a:eq(4)").addClass("on");
			$(".btn5").addClass("sel");
			k=5;
			//숨긴 내용 보이게 만들기. ▽
			$("#contact_bg div:eq(0)").animate({"opacity":"1","top":"50%"},500);
		}
		return false;
	});
	
	// 화살표 버튼 클릭시 화면 전환 시키기.
	var h = $(window).height();
	$(".no1").click(function(){
		$("html").stop().animate({scrollTop : h},500);
	});
	$(".no2").click(function(){
		$("html").stop().animate({scrollTop : h*2},500);
	});
	$(".no3").click(function(){
		$("html").stop().animate({scrollTop : h*3},500);
	});
	$(".no4").click(function(){
		$("html").stop().animate({scrollTop : h*4},500);
	});
	
});//end