$(document).ready(function(){
    //wrap
    
    $(".photo li:last").prependTo(".photo");
    $(".photo").css("margin-left","-313px");
    $(".btn:first").addClass("active");
    
    $(".next").click(function(){ //>
        $(".photo:not(:animated)").animate({marginLeft:parseInt($(".photo").css("margin-left"))-313+"px"},"slow","swing",function(){
            $(".photo li:first").appendTo(".photo");
            $(".photo").css("margin-left","-313px");
            var n = $(".photo li").attr("data-n");
            n++;
            //console.log(n); 2 3 4 5 6
            if(n==6){
                n = 1;
            }
            $(".btn").removeClass("active");
            $(".btn"+n).addClass("active");
        });
    });
    
    $(".prev").click(function(){ //<
        $(".photo:not(:animated)").animate({marginLeft:parseInt($(".photo").css("margin-left"))+313+"px"},"slow","swing",function(){
            $(".photo li:last").prependTo(".photo");
            $(".photo").css("margin-left","-313px");
            var n = $(".photo li").attr("data-n");
            n++;
            //console.log(n); 5 4 3 2 6
            if(n==6){
                n = 1;
            }
            $(".btn").removeClass("active");
            $(".btn"+n).addClass("active");
        });
    });
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
});