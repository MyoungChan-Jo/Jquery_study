function banner1(){
    $(".food").animate({
        marginLeft:parseInt($(".food").css("margin-left"))-240+"px"
    },"slow",function(){
        $(".food li:first").appendTo(".food");
        $(".food").css("margin-left","-240px");
    });
}


$(document).ready(function(){
    //food_all
    
    var width1 = 240 * $(".food li").size()+"px";
    $(".food").css("width",width1);
    $(".food li:last").prependTo(".food"); //마지막 li 맨앞으로 이동
    $(".food").css("margin-left","-240px");
    
    var banner = setInterval("banner1()",5000);
    
    $(".food li").mouseover(function(){
        clearInterval(banner);
        $(this).find("img").css("opacity","0.5");
    }).mouseout(function(){
        banner = setInterval("banner1()",5000);
        $(this).find("img").css("opacity","1");
    });
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
});