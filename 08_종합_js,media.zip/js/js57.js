$(document).ready(function(){
    //
    
    $("#number_bgimg").before("<p class='txt'>0</p>")
    
    $(".txt").css({"position":"fixed","left":"100px","top":"100px","color":"black","margin":"0","padding":"0"});
    
    $(".num_img").css("opacity","0");
    
    $(window).scroll(function(){
        $(".txt").text($(this).scrollTop());
        
        if($(this).scrollTop() > 1200){
            $(".no_01").animate({"opacity":"1"});
            $(".no_01_01").animate({"marginLeft":"0"},1000);
            $(".ap500_01 > span").animate({"marginLeft":"0"},1500);
            $(".ap500_01 > p").delay(500).animate({"marginLeft":"0"},1000);
        }
        if($(this).scrollTop() > 1500){
            $(".no_02").animate({"opacity":"1"});
            $(".no_02_01").animate({"marginLeft":"0"},1000);
            $(".af01_02 > span").animate({"marginLeft":"0"},1500);
            $(".af01_02 > p").delay(500).animate({"marginLeft":"0"},1000);
        }
        if($(this).scrollTop() > 1800){
            $(".no_03").animate({"opacity":"1"});
            $(".no_03_01").animate({"marginLeft":"0"},1000);
            $(".shl-01_03 > span").animate({"marginLeft":"0"},1500);
            $(".shl-01_03 > p").delay(500).animate({"marginLeft":"0"},1000);
        }
        if($(this).scrollTop() > 2100){
            $(".no_04").animate({"opacity":"1"});
            $(".no_04_01").animate({"marginLeft":"0"},1000);
            $(".ar-01_04 > span").animate({"marginLeft":"0"},1500);
            $(".ar-01_04 > p").delay(500).animate({"marginLeft":"0"},1000);
        }
    });
    
    
    
    
    
    
    
    
    
    
    
});