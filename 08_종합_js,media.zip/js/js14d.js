$(document).ready(function(){
    //wrap
    $("#wrap dl dd:not(:first)").hide(); 
    $("#wrap dl dt:first a").addClass("selected1");
    
    $("#wrap dl dt a").click(function(){
        $("#wrap dl dt a").removeClass("selected1");
        $(this).addClass("selected1");
        
        //클릭한 a의 부모 dt 다음에 있는 dd가 none이면
        if($(this).parent().next().css("display")=="none"){
            $("#wrap dl dd").slideUp("fast");
            $(".star_wrap img").attr("src","images/star1.png");
        }
        $(this).parent().next().slideDown("fast");
    });
    
    $(".star_wrap img").click(function(){
        $(".star_wrap img").attr("src","images/star1.png");
        $(this).attr("src","images/star2.png");
        $(this).prevAll("img").attr("src","images/star2.png");
    });
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
});