$(document).ready(function(){
    //top_wrap
    
    //태그추가
    $("#main_navi").before("<div class='bg'></div>");
    
    //추가 태그
    $(".bg").hide();
    $(".sub").hide();
    $("#menu").mouseover(function(){
        $(".bg").show();
        $(".sub").show();
    }).mouseout(function(){
        $(".bg").hide();
        $(".sub").hide();
    });
    
    $(".bg").mouseover(function(){
        $(this).show()
        $(".sub").show();
    }).mouseout(function(){
        $(this).hide();
        $(".sub").hide();
    });
    
    //추가된 태그에 이미지 변경
    $(".menu1, .sub1").mouseover(function(){//이용안내
        $(".bg").css("background-image","url(images/hybg1.jpg)");
    });
    $(".menu2, .sub2").mouseover(function(){//전시
        $(".bg").css("background-image","url(images/hybg2.jpg)");
    });
    $(".menu3, .sub3").mouseover(function(){//프로그램
        $(".bg").css("background-image","url(images/hybg3.jpg)");
    });
    $(".menu4, .sub4").mouseover(function(){//소개
        $(".bg").css("background-image","url(images/hybg4.jpg)");
    });
    $(".menu5, .sub5").mouseover(function(){//나만의 페이지
        $(".bg").css("background-image","url(images/hybg5.jpg)");
    });
    
    //Language 내용 보이기/숨기기
    
    $(".lang_li > ul").hide();
    var show1 = false;
    $(".lang_li").click(function(){
        show1 = !show1;
        if(show1==true){//show1 = true
            $(".lang_li").children("ul").show();
            $(".lang_li > span").text("▲").css("color","red");
            $(".lang_li > a").css("color","red");
        }else{//show1 = false
            $(".lang_li").children("ul").hide();
            $(".lang_li > span").text("▼").css("color","");
            $(".lang_li > a").css("color","");
        }
    });
    
    
    
    
    
    
    
    
    
    
    
    
    
});