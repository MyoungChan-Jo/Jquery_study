$(document).ready(function(){
    //wrap
    //.tab li a에 .sel로 설정되어 있는 href와 같은 이름의 .list li를 제외한 나머지 li는 숨김
    $(".list li.notice:not("+$('.tab li a.sel').attr('href')+")").hide();
    $(".tab li a").click(function(){
        $(".tab li a").removeClass("sel");
        $(this).addClass("sel");
        $(".list li.notice").hide();
        $($(this).attr("href")).show();
        return false;
    });
    
    
    
    
    
    
    
});