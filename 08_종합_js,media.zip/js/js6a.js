$(document).ready(function(){
    //wrap
    $(window).resize(function(){
        var w = parseInt($(this).width());
        $(".txt span").text(w);
        if(w >= 1024){ //1024이상
            $(".img1 img").attr("src","images/banner1.jpg").css("border-color","red");
        }else if(w >= 761 && w < 1024){ //761~1023
            $(".img1 img").attr("src","images/banner2.jpg").css("border-color","green");
        }else{ //760이하
            $(".img1 img").attr("src","images/banner3.jpg").css("border-color","pink");
        }
    }).resize();
    
    
});