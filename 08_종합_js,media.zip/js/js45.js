$(document).ready(function(){
    //wrap
    /*
    $(".submenu").hide();
    $("#menu > li").hover(function(){
        $(this).children("ul").show();
    },function(){
        $(this).children("ul").hide();
    });
    */
    
    /*
    $(".submenu").hide();
    $("#menu > li").hover(function(){
        $(this).children("ul").stop().fadeIn();
    },function(){
        $(this).children("ul").stop().fadeOut();
    });
    */
    
    $(".submenu").hide();
     $("#menu > li >a").on("mouseenter",function(){
        $(this).next("ul").stop().fadeIn();
     });
    $("#menu > li").on("mouseleave",function(){
        $(this).children("a").next("ul").stop().fadeOut();
     });
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
});