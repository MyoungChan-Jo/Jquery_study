$(document).ready(function(){
    //photo_wrap
    $(".caption1").css("opacity","0");
    $(".photo").mouseover(function(){
        $(".caption1",this).stop().animate({opacity:"1"},600);
    }).mouseout(function(){
        $(".caption1",this).stop().animate({opacity:"0"},600);
    });
    
    //photo_wrap2
    $("#photo_wrap2 ul li").mouseenter(function(){
        $(".photo_img:not(:animated)").animate({top:"-45px"},300);
        $(".photo_con:not(:animated)").animate({bottom:"-0"},300);
    }).mouseleave(function(){
        $(".photo_img:not(:animated)").animate({top:"-0"},300);
        $(".photo_con:not(:animated)").animate({bottom:"-45px"},300);
    });
    
    //photo_wrap3
    $("#photo_wrap3 p img:eq(1)").css("opacity","0");
    $("#photo_wrap3").mouseover(function(){
        $("#photo_wrap3 p img:eq(1)").stop().animate({opacity:"1"},600);
    }).mouseout(function(){
        $("#photo_wrap3 p img:eq(1)").stop().animate({opacity:"0"},600);
    });
    
    //box_wrap
    $(".box span").click(function(){
        var n = $(this).attr("date-value");
        $("#box_wrap .box"+n).slideUp(500);
    });
    
    
    
    
    
    
    
    
    
    
    
    
});