$(document).ready(function(){
    window.onload = function () { 

var elm = ".contents";

$(elm).each(function (index) {

// 개별적으로 Wheel 이벤트 적용

$(this).on("mousewheel DOMMouseScroll", function (e) {

e.preventDefault();

var delta = 0;

if (!event) event = window.event;

if (event.wheelDelta) {

delta = event.wheelDelta / 120;

if (window.opera) delta = -delta;

} 

else if (event.detail)

delta = -event.detail / 3;

//var moveTop = $(window).scrollTop();
    
var moveLeft = $(window).scrollLeft();

var elmSelecter = $(elm).eq(index);

// 마우스휠을 오른쪽에서 왼쪽으로

if (delta < 0) {

if ($(elmSelecter).next() != undefined) {

try{

//moveTop = $(elmSelecter).next().offset().top;
    
moveLeft = $(elmSelecter).next().offset().left;

}catch(e){}

}

// 마우스휠을 왼쪽에서 오른쪽

} else {

if ($(elmSelecter).prev() != undefined) {

try{

//moveTop = $(elmSelecter).prev().offset().top;
    
moveLeft = $(elmSelecter).prev().offset().left;

}catch(e){}

}

}



// 화면 이동 0.8초(800)

$("html,body").stop().animate({

//scrollTop: moveTop + 'px'
    
scrollLeft: moveLeft + 'px'

}, {

duration: 800, complete: function () {

}

});

});

});

}
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
});