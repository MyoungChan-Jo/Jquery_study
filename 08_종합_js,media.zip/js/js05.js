$(document).ready(function(){
    //login 숨기기
    $("#login").hide();
    
    //login 닫기
    $(".close_login").click(function(){
        $("#login").fadeOut();
        $("#layer").fadeOut();
    });
    
    //모달태그 추가
    $("body").append("<div id='layer'></div>");
    
    //모달태그 숨기기
    $("#layer").hide();
    
    //개인로그인
    $(".q2_btn").click(function(){
        $("#login").fadeIn();
        $("#layer").fadeIn();
    });
    
    //quick 빠른메뉴 / 개인로그인 / 기업로그인
    $("#quick li:first a").addClass("sel");
    $("#quick li a").click(function(){
        $("#quick li a").removeClass("sel");
        $(this).addClass("sel");
    });
    
    //빠른메뉴 숨기기/보이기
    $("#q1_menu").hide();
    $(".quick1 a").click(function(){
        //$("#q1_menu").show();
        $("#q1_menu").fadeIn();
    });
    
    //빠른메뉴 닫기
    $(".close_btn a").click(function(){
        //$("#q1_menu").hide();
        $("#q1_menu").fadeOut();
    });
    
});