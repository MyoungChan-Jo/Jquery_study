$(document).ready(function(){
    //txt_roll
    
    var h = 50; //li하나당 높이
    var speed = 2000; //2초
    
    var ul1 = $("#txt_roll > ul");
    var nValue = -h;
    var length1 = $("#txt_roll > ul > li").size(); //li 개수 14
    var nTop = 0;
    
    ul1.css({top:nTop}); //초기위치
    
    setInterval(function(){
        nTop += nValue;
        //console.log(nTop); -50 -100 -150 -200 ..
        if(nTop<-(length1/2*h)){
            nTop = -h;
            ul1.css({top:0});
        }
        ul1.animate({top:nTop},1000);
    },speed);
    
    
    
});