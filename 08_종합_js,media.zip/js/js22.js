$(document).ready(function(){
    //notice_wrap
    
    var width1 = 320 * $("#notice li").size()+"px"; //.size() selector 개수 320*li 개수
    $("#notice").css("width",width1);
    //alert(width1); 320 * 6 = 1920
    $("#notice li:last").prependTo("#notice");//마지막 li를 맨앞으로 이동
    $("#notice").css("margin-left","-320px");
    
    $(".prev_btn").click(function(){//<
        $("#notice:not(:animated)").animate({marginLeft:parseInt($("#notice").css("margin-left"))-320+"px"},"slow","swing",function(){
            $("#notice li:first").appendTo("#notice");//맨앞 li를 맨뒤로 이동
            $("#notice").css("margin-left","-320px");
        });
    });
    
    $(".next_btn").click(function(){//>
        $("#notice:not(:animated)").animate({marginLeft:parseInt($("#notice").css("margin-left"))+320+"px"},"slow","swing",function(){
            $("#notice li:last").prependTo("#notice");//맨뒤 li를 맨뒤로 이동
            $("#notice").css("margin-left","-320px");
        });
    });
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
});