$(document).ready(function(){
    //
    
    $("#wrap > div > a").mouseenter(function(){
        $(this).css({backgroundColor:"#333333",color:"#ffffff"});
    }).mouseleave(function(){
        $(this).css({backgroundColor:"#cccccc",color:"#666666"});
    }).click(function(){
        $(".plus").removeClass("on");
        $(this).find("span").addClass("on");
        $("#wrap > div > p").removeClass("on");
        $(this).siblings("p").addClass("on");
    });
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
});