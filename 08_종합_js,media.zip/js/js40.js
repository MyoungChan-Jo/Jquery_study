$(document).ready(function(){
    //wrap
    
    var x = 0;
    var i = "";
    var auto = setInterval(function(){
        move_left();
    },500);
    
    function move_left(){
        x -= 1;
        i = "left";
        if(x <= -100){//-100이하가 될때
            x = 0;
        }
        $(".container").css("left",x+"%");
        //console.log(x); -1 -2..
    }
    
    function move_right(){
        x += 1;
        i = "right";
        if(x>=0){
            x = -100;
        }
        $(".container").css("left",x+"%");
        //console.log(x);
    }
    
    $(".container").mouseenter(function(){
        clearInterval(auto);
    });
    $(".container").mouseleave(function(){
        if(i=="left"){//이전에 왼쪽으로 이동중이라면..
            auto = setInterval(function(){move_left()},500);        
        }else{
            auto = setInterval(function(){move_right()},500);
        }
    });
    
    $(".btn_left").click(function(){
        clearInterval(auto);
        auto = setInterval(function(){move_right()},500);
    });
    
    $(".btn_right").click(function(){
        clearInterval(auto);
        auto = setInterval(function(){move_left()},500);
    });
    
    
    
    
    
    
});