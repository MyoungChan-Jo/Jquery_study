$(document).ready(function(){
    //전체선택/전체해제
    $("#chk1").change(function(){
        var chk1 = $("#chk1").prop("checked");
        if(chk1 == true){
            $("#chk2,#chk3").prop("checked",true);
            $(".type01").addClass("checked");
        }else{
            $("#chk2,#chk3").prop("checked",false);
            $(".type01").removeClass("checked");
        }
    });
    
    $("#chk2,#chk3").change(function(){
        var chk2 = $("#chk2").prop("checked");
        var chk3 = $("#chk3").prop("checked");
        if(chk2==true){ //#chk2
            $(".type03").addClass("checked");
        }else{
            $(".type03").removeClass("checked");
        }
        if(chk3==true){ //#chk3
            $(".type04").addClass("checked");
        }else{
            $(".type04").removeClass("checked");
        }
        if(chk2==true&&chk3==true){
            $("#chk1").prop("checked",true); //전체선택
            $(".type02").addClass("checked");
        }else{
            $("#chk1").prop("checked",false);
            $(".type02").removeClass("checked");
        }
    });
    
    
    
    
    
    
    
    
    
});