$(document).ready(function(){
    //옵션 http://github.com/kottenator/jquery-circle-progress
    
    //wrap
    
    var i = 0;
    $("#wrap").css("opacity","0");
    $(window).scroll(function(){
        var h = $("html").scrollTop();
        if(h >= 500 && i == 0){
            $("#wrap").animate({"opacity":"1"});
            $(".first").circleProgress({
                value : 0.9,//그래프에 표시될 값
                fill : "#9999ff",//채우기 색
                size : 200,//그래프 크기
                thickness : 14,//그래프두께
                startAngle : 200 //시작지점
            }).on("circle-animation-progress",function(event,progress){
                $(this).find("strong").html(Math.round(80*progress)+"<i>%</i>");
            });
            $(".second").circleProgress({
                value : 0.5,//그래프에 표시될 값
                fill : {gradient:["green","yellow","pink"]},//채우기 색
                size : 100,//그래프 크기
                thickness : 10,//그래프두께
                startAngle : 30 //시작지점
            }).on("circle-animation-progress",function(event,progress){
                $(this).find("strong").html(Math.round(50*progress)+"<i>%</i>");
            });
            $(".third").circleProgress({
                value : 0.7,//그래프에 표시될 값
                size : 150,//그래프 크기
                thickness : 10,//그래프두께
            }).on("circle-animation-progress",function(event,progress){
                $(this).find("strong").html(Math.round(70*progress)+"<i>%</i>");
            });
            
            
            i++;
        }
        
    });
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
});