$(document).ready(function(){
    //food_all
    //.size() selector 개수
    
    var w = 944 * $(".food").size()+"px"; //944*ul 개수 4
    //alert(w); 3776px
    $("#food_wrap").css("width",w);
    $(".food:last").prependTo("#food_wrap"); //마지막 ul울 맨앞으로 이동
    $("#food_wrap").css("margin-left","-944px");
    
    $(".prev").click(function(){//<
       $(".prev, .next").hide(); $("#food_wrap:not(:animated)").animate({marginLeft:parseInt($("#food_wrap").css("margin-left"))-944+"px"},"slow","swing",function(){
            $(".food:first").appendTo("#food_wrap");//맨 처음ul 맨뒤로 이동
            $("#food_wrap").css("margin-left","-944px");
            $(".prev, .next").show(); 
        });
    });
    
    $(".next").click(function(){//>
       $(".prev, .next").hide(); $("#food_wrap:not(:animated)").animate({marginLeft:parseInt($("#food_wrap").css("margin-left"))+944+"px"},"slow","swing",function(){
            $(".food:last").prependTo("#food_wrap");//마지막 ul 맨앞으로 이동
            $("#food_wrap").css("margin-left","-944px");
            $(".prev, .next").show(); 
        });
    });
    
    
    
    
    
    
    
});