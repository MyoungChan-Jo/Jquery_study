$(document).ready(function(){
    //옵션 : http://github.com/wayou/SlipHover#options
    
    //wrap
    
    $("#container").sliphover({
        
    });
    
    //wrap2
    
    $("#container2").sliphover({
        backgroundColor:"#9999ff" //배경색
    });
    
    //wrap3
    
    $("#container3").sliphover({
        fontColor:"yellow" //글자색
    });
    
    //wrap4
    
    $("#container4").sliphover({
        textAlign:"left", //왼쪽정렬
        verticalMiddle:false //위쪽정렬
    });
    
    //wrap5
    
    $("#container5").sliphover({
        withLink:false ,//링크속성 해제
    });
    
    
    
    
    
    
    
    
    
    
    
    
});