$(document).ready(function(){
    //notice_wrap
    
    var w = 320*$("#notice li").size()+"px";
    $("#notice").css("width",w);
    
    $("#notice li:last").prependTo("#notice");
    $("#notice").css("margin-left","-320px");
    
    $(".photo2_bg li:not(:first)").fadeOut(); //1번이미지 title
    $(".photo2_bg2 li:not(:first)").hide(); //1번이미지 설명입니다.
    
    $(".prev_btn").click(function(){ //<
        $("#notice:not(:animated)").animate({marginLeft:parseInt($("#notice").css("margin-left"))+320+"px"},"slow","swing",function(){
            $("#notice li:last").prependTo("#notice");
            $("#notice").css("margin-left","-320px");
            
            var n = $("#notice li").attr("data-n");
            n++;
            if(n==6){
                n = 1;
            }
            $(".photo2_bg li").fadeOut(1000);
            $(".photo2_bg .se"+n).fadeIn(1000);
            $(".photo2_bg2 li").hide();
            $(".photo2_bg2 .se2"+n).show();
            //console.log(n);
        });
    });
    
    $(".next_btn").click(function(){ //>
        $("#notice:not(:animated)").animate({marginLeft:parseInt($("#notice").css("margin-left"))-320+"px"},"slow","swing",function(){
            $("#notice li:first").appendTo("#notice");
            $("#notice").css("margin-left","-320px");
            
            var n = $("#notice li").attr("data-n");
            n++;
            if(n==6){
                n = 1;
            }
            $(".photo2_bg li").fadeOut(1000);
            $(".photo2_bg .se"+n).fadeIn(1000);
            $(".photo2_bg2 li").hide();
            $(".photo2_bg2 .se2"+n).show();
            //console.log(n);
        });
    });
    
    
    
    
    
    
    
    
    
    
    
    
    
    
});