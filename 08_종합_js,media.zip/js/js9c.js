$(document).ready(function(){
    //wrap
    $("#menu li a:first").addClass("active");
    $("#menu li a").click(function(){
        $("#menu li a").removeClass("active");
        $(this).addClass("active");
    });
    
    var all = $("#all");
    var m1 = $("#m1");
    var m2 = $("#m2");
    var m3 = $("#m3");
    var grid = $("#grid");
    grid.isotope({
        itemSelector: ".grid-item",
        masonry:{columnWidth:300}
    });
    all.click(function(){
        grid.isotope({filter:".menu"})
    });
    m1.click(function(){
        grid.isotope({filter:".menu1"})
    });
    m2.click(function(){
        grid.isotope({filter:".menu2"})
    });
    m3.click(function(){
        grid.isotope({filter:".menu3"})
    });
});