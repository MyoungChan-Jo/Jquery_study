$(document).ready(function(){
    //test
    //$(selcetor).index() 지정된 요소의 인덱스 번호를 반환(0부터 시작)
    //찾을 수 있으면 -1 반환
    $(".test li").click(function(){
        alert($(this).index());
    });
    
    //wrap1
    
    /*$("#wrap1 p").eq(0).mouseenter(function(){
        //$(selcertor).find(조건) selector에서 조건에 맞는 요소 찾음
        $(this).find("img").attr({src:"images/hybg3.jpg"});
    }).mouseleave(function(){
        $(this).find("img").attr({src:"images/hybg1.jpg"});    
    });
    $("#wrap1 p").eq(1).mouseenter(function(){
        $(this).find("img").attr({src:"images/hybg4.jpg"});
    }).mouseleave(function(){
        $(this).find("img").attr({src:"images/hybg2.jpg"});    
    });*/
    
    $("#wrap1 p").mouseenter(function(){
        var i = $(this).index(); //0부터 시작
        $(this).find("img").attr({src:"images/hybg"+(i+3)+".jpg"});
    }).mouseleave(function(){
        var i = $(this).index(); //0부터 시작
        $(this).find("img").attr({src:"images/hybg"+(i+1)+".jpg"});
    });
    
    //wrap2
    $(".tab_menu h2 a").click(function(){
        $(".tab_con .con").hide(); //모두 숨기기
        var n2 = $(this).parent().index(); //a의 부모 h2인덱스
        $(".tab_con .con").eq(n2).show();
        return false;
    });
    
    //wrap3
    $("#btn p").click(function(){
        var n3 = $(this).index();
        $("#btn p").removeClass("on");
        $(this).addClass("on");
        $("#tab p").removeClass("on");
        $("#tab p").eq(n3).addClass("on");
        return false;
    });
    
    //wrap4
    $("#btn4 p a").click(function(){
        $("#btn4 p a").removeClass("sel");
        $(this).addClass("sel");
        
    });
    $("#btn4 p").click(function(){
        $("#tab4 div").removeClass("on4");
        var n4 = $(this).index();
        $("#tab4 div").eq(n4).addClass("on4");
        return false;
    });
    
    //wrap5
    $("#tab5 > li:first > a").addClass("on5");
    $("#contents5 > p:first").css("display","block");
    $("#tab5 li").click(function(){
        $("#tab5 > li > a").removeClass("on5");
        $(this).find(">a").addClass("on5");
        var n5 = $(this).index();
        $("#contents5 > p").css("display","none");
        $("#contents5 > p").eq(n5).css("display","block");
        return false;
    });
    
    
    
    
    
    
    
    
    
    
    
});