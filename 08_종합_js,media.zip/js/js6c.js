$(document).ready(function(){
    $(window).resize(function(){
        var width1 = parseInt($(this).width());
        if(width1 > 1024){ //1024초과
            $("body").css("width","100%");
        }else if(width1 <= 1024){ //1024이하
            $("body").css("width","1024px");
        }else if(width1 <= 900){ //900이하
            $("body").css("width","900px");   
        }else{
            $("body").css("width","100%"); 
        }
    }).resize();
    
});