$(document).ready(function(){
    //bottom1
    $("#bottom1 > select").change(function(){
        var selectValue = $("#bottom1 > select option:selected").val();//선택한 option의 value
        window.open(selectValue);//새창(탭)으로 selectValue 띄우기
        $(this).find("option:eq(0)").prop("selected",true);
    });
    
    //체크박스 체크 : .attr - checked 반환, .prop - true 반환
    //체크박스 해제 : .attr - checked 반환, .prop - fasle 반환
    //select 1번째 항목 선택 : .attr - undefined?, .prop - true 반환
    //select 다른항목 선택 : .attr - undefined?, .prop - false 반환
    
    
    //bottom2
    $("#bottom2 > input:button").click(function(){
        var selectValue2 = $("#bottom2 > select option:selected").val();
        window.open(selectValue2);
        $("#bottom2 > select").find("option:eq(0)").prop("selected",true);
    });
    
    //bottom3
    $(".site ul").hide();
    
    var check1 = false;
    $(".site h4").click(function(){
        check1 =!check1;
        if(check1==true){
            $(".site ul").show();
        }else{
            $(".site ul").hide();
        }
    });
    
    $(".site ul li").click(function(){
        var src1 = $(this).attr("data-link");
        $(".site ul li").css("color","");
        $(this).css("color","#000000");
        $("p.go a").attr("href",src1).css("color","#333333");
    });
    $("p.go a").click(function(){
        $(".site ul").hide();
        $(".site ul li").css("color","#ffffff");
    });
    
    //bottom4
    $("#family_site4 > ul").slideUp(0);
    var cnt1 = 1;
    $("#family_site4 > button").click(function(){
        if(cnt1 == 1){
            $("#family_site4 > ul:not(:animated)").slideDown("fast");
            $(".icon4").text("∨");
            cnt1 = 0;
        }else{
            $("#family_site4 > ul:not(:animated)").slideUp("fast");
            $(".icon4").text("∧");
            cnt1 = 1;
        }
    });
    //접근성, 탭키 js
    $("#family_site4").focusin(function(){
        $("#family_site4 > ul").slideDown("fast");
        $(".icon4").text("∨");
    });
    $("#family_site4 > ul > li:last > a").focusout(function(){
        $("#family_site4 > ul").slideUp("fast");
        $(".icon4").text("∧");
    });
    
    //bottom5
    $("#family_site5 > ul").animate({top:150},0);
    var cnt2 = 1;
    $("#family_site5 > button").click(function(){
        if(cnt2 == 1){
            $("#family_site5 > ul:not(:animated)").animate({top:1},"fast");
            $(".icon5").text("∧");
            cnt2 = 0;
        }else{
            $("#family_site5 > ul:not(:animated)").animate({top:150},"fast");
            $(".icon5").text("∨");
            cnt2 = 1;
        }
    });
    //접근성, 탭키 js
    $("#family_site5").focusin(function(){
        $("#family_site5 > ul").animate({top:1},"fast");
        $(".icon5").text("∧");
    });
    $("#family_site5 > ul > li:last > a").focusout(function(){
        $("#family_site5 > ul").animate({top:150},"fast");
        $(".icon5").text("∨");
    });
    
    
    
    
    
});