$(document).ready(function(){
    //wrap
    $(window).resize(function(){
        var width1 = parseInt($(this).width());
        $(".txt").text(width1);
        if(width1 >= 1024){ //1024이상
            $("link").attr("href","css/layout_1024.css");
        }else if(width1 >= 761){ //761~1023(width1 >= 761 && width1 < 1024)
            $("link").attr("href","css/layout_761.css");
        }else{ //760이하
            $("link").attr("href","css/layout_760.css");
        }
    }).resize();
    
    
});