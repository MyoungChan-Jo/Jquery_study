$(document).ready(function(){
    //wrap
    //첫번째 dd제외한 나머지 dd너비 0
    $("#menu_wrap dd:not(:first)").css("width","0px");
    
    //첫번째 dt 클래스 추가
    $("#menu_wrap dt:first").addClass("selected1");
    $("#menu_wrap dt").click(function(){
        $("#menu_wrap dt").removeClass("selected1");
        $(this).addClass("selected1");
        if($(this).next().css("width")=="0px"){
            $("#menu_wrap dd:not(:animated)").animate({width:"0px"},"fast");
            $(this).next().animate({width:"700px"},"fast");
        }
    }).mouseover(function(){
        $(this).addClass("over1");
    }).mouseout(function(){
        $(this).removeClass("over1");
    });
    
    
    
    
    
    
    
    
    
    
    
    
    
});