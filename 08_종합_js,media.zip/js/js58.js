$(document).ready(function(){
    
    
    $(window).load(function(){
        setTimeout(function(){
            $(".box1_1").addClass("sel1");
        },100);
        setTimeout(function(){
            $(".box1_2").addClass("sel1");
        },300);
        setTimeout(function(){
            $(".box1_3").addClass("sel1");
        },500);
    });
    
    $(window).scroll(function(){
        var st = $(window).scrollTop();
        var h = $(window).height();
        
        var offset1 = $("#section1").offset().top;
        var offset2 = $("#section2").offset().top;
        var offset3 = $("#section3").offset().top;
        
        //section1 container1
        
        if(st > offset2 - h*0.5){
            $(".container1 div").each(function(){
                var obj = $(this);
                setTimeout(function(){
                    obj.removeClass("sel1");
                },obj.attr("data-time"));
            });
        }else{
            $(".container1 div").each(function(){
                var obj = $(this);
                setTimeout(function(){
                    obj.addClass("sel1");
                },obj.attr("data-time"));
            });
        }
        
        //section2 container2
    
        if(st >= offset2 - h*0.5 && st < offset3 - h*0.5){
            setTimeout(function(){
                $(".box2_1").addClass("sel2");
            },100);
            setTimeout(function(){
                $(".box2_2").addClass("sel2");
            },200);
            setTimeout(function(){
                $(".box2_3").addClass("sel2");
            },400);
        }else{
            setTimeout(function(){
                $(".box2_1").removeClass("sel2");
            },100);
            setTimeout(function(){
                $(".box2_2").removeClass("sel2");
            },200);
            setTimeout(function(){
                $(".box2_3").removeClass("sel2");
            },400);
        }
        
        //section3 container3
        
        if(st > offset3 - h*0.5){
            $(".container3 div").addClass("sel3");
        }else{
            $(".container3 div").removeClass("sel3");
        }
        
        
        
        
    });//scroll end
    
    
    
    
    
    
    
    
    
    
    
});