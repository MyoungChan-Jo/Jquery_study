$(document).ready(function(){
    //wrap
    
    var i = 0;
    var auto = setInterval(function(){
        i++;
        if(i<3){
            $("#img_wrap img").removeClass("on");
            $("#img_wrap img").eq(i).addClass("on");
            $("#btn p").removeClass("on");
            $("#btn p").eq(i).addClass("on");
            //console.log(i); 1 2
        }else{
            i = 0;
            $("#img_wrap img").removeClass("on");
            $("#img_wrap img").eq(i).addClass("on");
            $("#btn p").removeClass("on");
            $("#btn p").eq(i).addClass("on");
            //console.log(i); 0
        }
    },3000);
    
    $("#btn p").click(function(){
        var num = $(this).index(); //클릭한 p의 인덱스 번호 저장 0 ~ 2
        $("#btn p").removeClass("on");
        $("#btn p").eq(num).addClass("on");
        $("#img_wrap img").removeClass("on");
        $("#img_wrap img").eq(num).addClass("on");
        
        var i = num;
        //console.log(i) 0 1 2
    });
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
});