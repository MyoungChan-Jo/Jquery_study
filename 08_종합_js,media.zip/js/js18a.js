$(document).ready(function(){
    //join_wrap
    $(".contents:not("+$(".join li a.j_sel").attr("href")+")").hide();
    
    //span 추가
    $(".j_txt1").not(":last").after("<span class='j_txt2'></span>");
    $(".join li:first a .j_txt2").addClass("j_txts"); //추가한 span에 class적용
    
    
    $(".join li a").click(function(){
        $(".join li a").removeClass("j_sel");//a
        $(this).addClass("j_sel");//a
        $(".j_txt2").removeClass("j_txts");
        $(".j_txt2",this).addClass("j_txts");
        $(".contents").hide();
        $($(this).attr("href")).show();
        return false;
        
    });
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
});