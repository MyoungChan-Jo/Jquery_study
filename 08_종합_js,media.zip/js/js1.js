$(document).ready(function(){
    //팝업창 띄우기 : 다른파일을 팝업으로 띄우기
    //1.팝업창 열기
    //window.open(파일명,창이름,옵션)
    //옵션: width(너비),height(높이),left(수평 x축),top(수직 y축),scrollbars(스크롤바 no,yes)
    //2.팝업창 닫기
    //window.close()
    
    $(".popup").click(function(){
       var href1 = $(this).attr("href");
        window.open(href1,"그래픽","width=400px,height=500px");
        return false;
    });
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
});