$(document).ready(function(){
    //1.비밀번호
    //$(selector).focus() 포커스가 있을 때
    //$(selector).blur() 포커스를 잃을 때
    $(".pwd1_con").hide();
    $("#pwd1").focus(function(){
        $(".pwd1_con").show();
    }).blur(function(){
        $(".pwd1_con").hide();
    });
    
    //2.과목
    //$(selector).val() Attributes영역, 선택한 요소의 값 속성을 반환하거나 설정, 대부분 HTML양식 요소와 함께 사용
    $("#btn2").click(function(){
        $("input[name='name2']").val("웹접근성").css("color","#990000"); 
    });
    
    //3.e-mail 주소
    $("#btn3").click(function(){
        $("#txt3").text($("#email3").val()+"로 메일이 전송됩니다.");
        $(this).text("전송하기");
    });
    
    //4.이름
    $("#btn4").click(function(){
        $("#name4").val("").focus(); 
    });
    
    //5.나이
    $(".btn5").click(function(){
        var num5 = $("#age").val();
        if(num5==""){
            alert("아무런 정보도 입력하지 않았습니다.");
            $("#age").focus();
        }else if(num5>=20){
            alert("성인입니다.");
        }else if(num5<20){
            alert("미성년자입니다.");
        }else{
            alert("숫자만 입력하세요");
            $("#age").val("").focus();
        }
    });
    
    //6.
    $("#frm6 input").focus(function(){
        $(this).addClass("focus6");
    }).blur(function(){
        $(this).removeClass("focus6");
    });
    
    //7.수강과목명
    /*$("#name7").val("입력하세요").css("color","#999999").focus(function(){
        $(this).val("").css("color","#9966cc"); 
    });*/
    //$(selector).one();  Event Handler Attachment 이벤트를 한번만 실행
    $("#name7").val("입력하세요").css("color","#999999").one("focus",function(){
        $(this).val("").css("color","#9966cc"); 
    }).blur(function(){
        if($(this).val()==""){
            $(this).val("입력하세요").css("color","#999999").one("focus",function(){
               $(this).val("").css("color","#9966cc") ;
            });
        } 
    });
    
    //8.신청자
    //$(selector).change(); 요소의 값이 변경되었을 때
    $("#select8").change(function(){
        //span의 텍스트를 선택한 옵션의 value로 변경
        $("#txt8 span").text($(this).val());
    });
    
    //9
    $("#email_l").focus().css("color","#999999");
    $("#email_list").change(function(){
        $("#email9 span input").val($(this).val()).css("color","#999999");
        if($(this).val()==""){
            $("#email9 span input").val("입력하세요").focus(function(){
                $(this).val(""); 
            });
        }
    });
    
    //10.수강과목 선택
    //일러스트레이터 선택 : illustrator / 300,000
    //포토샵 선택 : photoshop / 250,000
    //플래시 선택 : flash / 200,000
    //드림위버 선택 : dreamweaver / 150.000
    //선택하세요 선택 : 과목을 선택하세요
    $("select[name='list10']").change(function(){
        $("#list_t10").val($(this).val());
        if($("select[name='list10']").val()=="illustrator"){
            $("#list_t11").val("300,000");
        }else if($("select[name='list10']").val()=="photoshop"){
            $("#list_t11").val("250,000");
        }else if($("select[name='list10']").val()=="flash"){
            $("#list_t11").val("200,000");
        }else if($("select[name='list10']").val()=="dreamweaver"){
            $("#list_t11").val("150,000");
        }else{
            $("#list_t11").val("");
            alert("과목을 선택하세요");
        }
    });
    
    //11.선택
    $("#select11").change(function(){
        //.html() 선택한 요소안의 내용을 가져오거나 다른내용으로 바꿔주는 메서드
        $("#photo11").html("<img src="+$(this).val()+" width='300' height='200'>");
    });
    
    //12.선택
    $("#con_wrap12 p:not(:first)").hide();
    $("#select12").change(function(){
        if($("#select12").val()=="1"){
            $("#con1").show();
            $("#con2,#con3").hide();
        }else if($("#select12").val()=="2"){
            $("#con2").show();
            $("#con1,#con3").hide();
        }else{
            $("#con3").show();
            $("#con1,#con2").hide();
        }
    });
    
    //13.선택
    $("#con_wrap13 p:not(:first)").hide();
    $("#select13").change(function(){
        $("#con_wrap13 p").hide();
        var n13 = $(this).val();
        $("#con_wrap13 #co"+n13).show();
    });
    
    //14.나이
    $("select[name='select14']").change(function(){
        //선택한 select의 value가 10이면 입력불가
        if($("select[name='select14'] :selected").attr("value")=="10"){
            //:enabled 입력가능한(활성화 된) 모든양식요소
            //:disabled 입력불가한(비활성화 된) 모든양식요소
            $("#sel_t").attr("disabled","disabled").val("").after("<span class='txt14'> 입력할 수 없습니다.</span>");
            $(".txt14").css("color","#990000");
        }else{
            $("#sel_t").removeAttr("disabled").val("");
            $(".txt14").remove();
        }
    });
    
    //15.지역선택
    $("#select15_2 option").hide(); //우측 select
    $("#select15_1").change(function(){ //좌측 select
        var n15 = $(this).val();
        $("#select15_2 option").hide();
        $("#select15_2 .s"+n15).show();
        $("#select15_2").val("선택하세요");
    });
    
    //16.*이름 ok.html 파일
    //$(selector).submit() 폼이벤트 / 양식이 전송 될 때 발생
    $("#frm16").submit(function(){
        if($("#name16").val()==""){
            if($(".txt16").text()==""){
            $("#name16").css("border","2px solid red").after("<span class='txt16'> 필수입니다.</span>");
            $(".txt16").css({"color":"red","font-size":"11px"});
            } 
        return false;
        }
    });
    
    //17.
    $("#btn17_1").mouseover(function(){ //전송
        $(this).after("<span class='txt17_1'> 입력한 내용을 서버로 전송합니다.</span>");
        $(".txt17_1").css("color","#990000");
    }).mouseout(function(){
        $(".txt17_1").remove(); 
    });
    
    $("#btn17_2").one("click",function(){ //다시작성
        $(this).after("<span class='txt17_2'> 입력한 내용이 모두 초기화 됩니다.</span>");
        $(".txt17_2").css("color","#990000");
    });
    
    //18.
    //비밀번호를 입력하세요 / 비밀번호가 일치하지 않습니다. / 성공입니다.
    $(".btn18").click(function(){
        var pwd1 = $("input[name='pwd1']").val(), //비밀번호
        pwd2 = $("input[name='pwd2']").val(); //비밀번호 확인
        if(pwd1 == ""||pwd2 == ""){
            alert("비밀번호를 입력하세요");
        }else if(pwd1 != pwd2){
            alert("비밀번호가 일치하지 않습니다.");
        }else{
            alert("성공입니다.");
        }
    });
    
    //19.
    $("#chk19").val("선택하세요").css({"color":"#999999"});
    $("#chk19_1").click(function(){
        $("#chk19").val("웹표준 선택"); 
    });
    $("#chk19_2").click(function(){
        $("#chk19").val("웹접근성 선택"); 
    });
    
    //20.
    //type="radio" :radio
    $("#radio_all :radio").change(function(){
        $(".list20").css({"font-weight":"","color":""});
        $("label[for="+$(this).attr("id")+"]").css({"font-weight":"bold","color":"#990000"});
    });
    
    //21.
    $("#txt21").hide();
    $("#chk21").click(function(){
        $("#txt21").toggle(); //selector show/hide
    });
    
    //22.
    $("#chk_all").change(function(){ //전체선택/해제
        //$(selector).prop(property)/Attributes 영역, 선택한 요소의 속성과 값을 설정하거나 반환
        //체크 o - true, 체크 x - false
        var checked1 = $(this).prop("checked");
        $("input[name='chk22']").prop("checked",checked1);
    });
    
    //HTM, CSS, JQUERY input
    $("input[name='chk22']").change(function(){
        var chk22_1 = $("#html2").prop("checked");
        var chk22_2 = $("#css2").prop("checked");
        var chk22_3 = $("#jquery2").prop("checked");
        if(chk22_1 == true&&chk22_2 == true&&chk22_3 == true){
            $("#chk_all").prop("checked",true);
        }else{
            $("#chk_all").prop("checked",false);
        }
    });
    
    //23.
    $(".chk_t").click(function(){
        var n23 = $(this).attr("id");
        $("input[name='chk23']").prop("checked",false);
        $("#chk"+n23).prop("checked",true);
    });
    
    //24.검색
    var n24 = false;
    $("#search1 a").click(function(){
        n24 = !n24;
        if(n24){
            $("#search1:not(:animated)").animate({width:"150px"},1000);
        }else{
            $("#search1:not(:animated)").animate({width:"30px"},1000);
        }
        return false;
    });
    
    //parseInt 숫자(정수)변환
    $(".show1").text(parseInt("12.68")); //12 소수점 아래 버림
    $(".show2").text(parseInt("12 68")); //12 공백이 있으면 앞숫자만
    $(".show3").text(parseInt("5 비와")); //5 숫자+문자일 경우 숫자만
    $(".show4").text(parseInt("비가 5네요")); //NaN 문자+숫자일 경우 NaN(Not a Number)
    
    //25.
    $("#plus").click(function(){ //▲
        var num_t = $(".num_txt").text(); //span
        var num = parseInt(num_t);
        num++;
        if(num>10){ //10초과
            alert("10까지만 입력");
            num=10;
        }
        $(".num_txt").text(num); //span
    });
    $("#minus").click(function(){ //▼
        var num_t = $(".num_txt").text(); //span
        var num = parseInt(num_t);
        num--;
        if(num<=0){ //0이하
            alert("1이상만 입력");
            num=1;
        }
        $(".num_txt").text(num); //span
    });
    
    //26.검색
    $("#search26").on("keyup",function(){
        //.ketup() 키보드 키가 눌려있다가 떼는 순간 발생
        var value1 = $(this).val().toLowerCase(); //소문자로 변경
        $("#list26 li").filter(function(){
            //.filter() 특정 기준과 일치하는 요소를 반환
            //.indexOf() 인덱스번호 반환(0부터 시작)
            //문자열에서 지정된 값이 처음 나타나는 위치, 검색 할 값이 발생하지 않으면 -1을 반환
            $(this).toggle($(this).text().toLowerCase().indexOf(value1)>-1);
        });
    });
    
    //27.검색
    $("#search27").on("keyup",function(){
        //.ketup() 키보드 키가 눌려있다가 떼는 순간 발생
        var value2 = $(this).val().toLowerCase(); //소문자로 변경
        $("#t_search tr").filter(function(){
            //.filter() 특정 기준과 일치하는 요소를 반환
            //.indexOf() 인덱스번호 반환(0부터 시작)
            //문자열에서 지정된 값이 처음 나타나는 위치, 검색 할 값이 발생하지 않으면 -1을 반환
            $(this).toggle($(this).text().toLowerCase().indexOf(value2)>-1);
        });
    });
    
    //28.
    $("#ex28 p").append("<div id='view'></div>"); //p안에서 맨뒤에 div추가
    //$("#ex28 p").append("<div id='view'>A</div>"); 테스트
    $("#pwd28").keypress(function(event){
        //.keypress() 키가 눌러있을 때 
        $("#view")
            //.text(event.which) 키값 반환
            .text(String.fromCharCode(event.which))
            //String.fromCharCode() 키값에 해당하는 아스키값을 문자로 바꿔줌
            .fadeIn(200,function(){
                $(this).fadeOut(200);
        });
    });
    
    //29.
    $("#chk29").click(function(){
        if($("#pwd29").attr("type")=="password"){
            $("#pwd29").attr("type","text");
        }else{
            $("#pwd29").attr("type","password");
        }
    });
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
});