$(document).ready(function(){
    //wrap
    /*
    $(".btn01").click(function(){
        $(".move").stop().animate({marginLeft:"0"},500);
    });
    
    $(".btn02").click(function(){
        $(".move").stop().animate({marginLeft:"-772px"},500);
    });
    
    $(".btn03").click(function(){
        $(".move").stop().animate({marginLeft:"-1544px"},500);
    });*/
    
    
    $("#btn button").click(function(){
        var i = $(this).index(); //0 1 2
        $(".move").stop().animate({marginLeft: -772 * i},500);
    });
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
});