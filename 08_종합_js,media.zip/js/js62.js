$(document).ready(function(){
	/*
	$(selector).animate({style},{options})
	▽ option ▽
	1.duration: 속도, 지속시간.
	2.complete: 애니메이션 완료 후 실행할 함수.
	3.step: 애니메이션 각 단계에서 실행할 함수.
	*/
	$(".counter_wrap li .counter").css("opacity","0");    //span에 투영도 0% 준다.
	$(".counter_wrap li .counter").animate({"opacity":"1"}); // 애니메이션 스타일 opacity 100%로 바로 나오게 실행.
	$(".counter").each(function(){
		var $this = $(this) , countTo = $this.attr("data-count"); //span태그에 속성 data-count를 변수에 넣는다.
		$({countNum : $this.text()}).animate({
			 // style ▽
			countNum : countTo
		},{ // option ▽
			duration:4500, /*지속시간:4.5초*/
			easing:"linear", /*효과:일정하게*/
			/*애니메이션 단계*/
			step:function(){
				/* ▽ 내림*/
				$this.text(Math.floor(this.countNum));},
				/* ▽ 완료후 실행*/
				complete : function(){$this.text(this.countNum);
				} // step:function △
		}); // countNum animate △
	}); // counter △
});// end ▲