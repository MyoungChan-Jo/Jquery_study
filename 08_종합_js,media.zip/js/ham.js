$(document).ready(function(){
    //wrap1
    $(".ham1 span").text("");
    $(".ham1").click(function(){ //p
        $(this).toggleClass("active1"); //addClass + removeClass 
    });
    
    //wrap2
    $(".ham2 span").text("");
    $(".ham2").on("click",function(){ //p
        $(this).find(".bar4").toggleClass("active2"); //addClass + removeClass 
    });
    
    //wrap3
    $(".ham3 span").text("");
    $(".ham3").on("click",function(){ //p
        $(this).find(".bar5").toggleClass("active3"); //addClass + removeClass 
    });
    
    //wrap4
    $(".ham4 span").text("");
    $(".ham4").on("click",function(){ //p
        $(this).find(".bar6").toggleClass("active4"); //addClass + removeClass 
    });
    
    
});