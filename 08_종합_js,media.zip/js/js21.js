$(document).ready(function(){
    //img_wrap1
    
    var img_fade1 = setInterval(function(){
        var showImg1 = $("#img_wrap1 img:eq(0)"); //첫번째 이미지
        var nextImg1 = $("#img_wrap1 img:eq(1)"); //두번째 이미지
        nextImg1.addClass("selected1");
        nextImg1.css("opacity","0").animate({opacity:1},1000,function(){
            showImg1.appendTo("#img_wrap1").removeClass("selected1");
        });
    },3000);
    
    //img_wrap2
    
    var img_fade2 = setInterval(function(){
        var showImg2 = $("#img_wrap2 img:eq(0)"); //첫번째 이미지
        var nextImg2 = $("#img_wrap2 img:eq(1)"); //두번째 이미지
        nextImg2.addClass("selected2");
        nextImg2.css("opacity","0").animate({opacity:1},1000,function(){
            showImg2.appendTo("#img_wrap2").removeClass("selected2");
        });
    },3000);
    
    //img_wrap3
    
    var img_fade3 = setInterval(function(){
        var showImg3 = $("#img_wrap3 p:eq(0)"); //첫번째 p
        var nextImg3 = $("#img_wrap3 p:eq(1)"); //두번째 p
        nextImg3.addClass("selected3");
        nextImg3.css("opacity","0").animate({opacity:1},1000,function(){
            showImg3.appendTo("#img_wrap3").removeClass("selected3");
        });
    },3000);
    
    //img_wrap4
    
    var img_fade4 = setInterval(function(){
        var showImg4 = $("#img_wrap4 p:eq(0)"); //첫번째 p
        var nextImg4 = $("#img_wrap4 p:eq(1)"); //두번째 p
        nextImg4.addClass("selected4");
        nextImg4.css("opacity","0").animate({opacity:1},1000,function(){
            showImg4.appendTo("#img_wrap4").removeClass("selected4");
        });
    },3000);
    
    //img_wrap5
    
    $(".slide li:gt(0)").hide(); //인덱스 번호가 지정된 번호보다 큰 요소(0부터 시작),첫번째 li빼고 모두 숨기기
    var img_fade5 = setInterval(function(){
        $(".slide li:first").fadeOut(3000).next().fadeIn(3000); //첫번째 li가 서서히 사라지고 다음 li가 서서히 나타남
        $(".slide li:first").appendTo(".slide");//첫번째 li는 slide안에서 맨뒤로 이동
    },3000);
    
    //img_wrap6
    
    $("#img_wrap6").children("div:gt(0)").hide(); //img_wrap6의 직접적인 자식요소
    var n = 0;
    var img_fade6 = setInterval(function(){
        var next = (n + 1) % 3; // (0 + 1) 1
        //console.log(next); 1
        $("#img_wrap6").children("div").fadeOut(3000); //0 첫번째 div 서서히 숨기기
        $("#img_wrap6").children("div").eq(next).fadeIn(3000);//다음 div 나타나기
        n = next;
        //console.log(n); 1 2 0 1 2 0 ...
        
    },3000);
    
    //img_wrap7
    
    //.end 최근 필터링을 끝내고 처음부터 다시,현재 선택된 요소의 이전 요소를 선택하는 메서드
    $(".photo7").find("a:gt(0)").hide();
    var img_fade7 = setInterval(function(){
        $(".photo7 a:first-child").fadeOut(3000).next("a").fadeIn(3000).end().appendTo(".photo7");
    },3000);
    
    
    
    
    
    
    
    
});