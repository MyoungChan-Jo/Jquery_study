function main_img(){
    $("#main_img").animate({
        marginLeft : parseInt($("#main_img").css("margin-left"))-730+"px"
    },"slow",function(){
        $("#main_img p:first").appendTo("#main_img");
        $("#main_img").css("margin-left","-730px");
    });
}

$(document).ready(function(){
    //main_wrap
    
    var width1 = 730 * $("#main_img p").size()+"px";
    $("#main_img").css("width",width1);
    //alert(width1); 2190px
    $("#main_img p:last").prependTo("#main_img");
    $("#main_img").css("margin-left","-730px");
    
    var timer = setInterval("main_img()",2000);
    
    $("#main_img").hover(function(){
        clearInterval(timer);
    }).mouseout(function(){
        timer = setInterval("main_img()",2000);
    });
    
    
    
    
    
    
    
    
    
    
    
    
    
    
});