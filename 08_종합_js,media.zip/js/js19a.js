$(document).ready(function(){
    //wrap
    
    $("#s_photo li a").click(function(){
        var href1 = $(this).attr("href");
        //$("#l_photo > img").attr("src",href1);
        $("#l_photo > img").before("<img src=" + href1 + ">");
        $("#l_photo > img:last").fadeOut("slow",function(){
            $(this).remove();  
        });
        return false;
    });
    
    $("#s_photo li a:first img").addClass("sel");
    $("#s_photo li a img").click(function(){
        $("#s_photo li a img").removeClass("sel");
        $(this).addClass("sel");
        //return false;
    });
    
    //wrap2
    
    $("#photo p:not(:first)").fadeOut();
    $("#btn p").click(function(){
        var  n = $(this).attr("data-value");
        $("#photo p").fadeOut(500);
        $("#photo .se" + n).fadeIn(500);
    });
    
    //wrap3
    
    var i = $(".s_img li").index();//index번호 0부터 1,2,3
    var leng = $(".s_img li").length;//li개수 4개
    
    function show_slider(){
        $(".s_img li").stop().fadeOut(1000);
        $(".s_img li").eq(i).stop().fadeIn(1000);
    }
    
    $(".next").click(function(){//다음
        if(i==leng-1){//클릭할때 li index번호와 li-1개수가 같으면
            i = 0;
        }else{//다르면
            i = i + 1 //li index에 1을 더해라
        }
        //console.log(i) 0 1 2 3 0 1 2 3..
        show_slider();
    });
    
    $(".prev").click(function(){
        if(i==0){
            i = leng-1;//4-1 = 3index, 4번째 li
        }else{
            i = i - 1;
        }
        //console.log(i)
        show_slider();
    });
    
    
    
    
    
    
    
    
    
    
    
    
    
    
});