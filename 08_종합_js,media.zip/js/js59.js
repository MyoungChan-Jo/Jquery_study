$(document).ready(function(){
	// 옵션: http://github.com/wayou/SlipHover#options
	
	//wrap1 기본값
	$("#container").sliphover({
	}); // #container △
	
	//wrap2
	$("#container2").sliphover({
		backgroundColor:"#9999ff" //배경색
	});// #container2 △
	
	//wrap3
	$("#container3").sliphover({
		fontColor:"yellow" //글자색
	});// #container3 △
	
	//wrap4
	$("#container4").sliphover({
		textAlign:"left", //글자 정렬
		verticalMiddle:false //위쪽 정렬
	});// #container4 △
	
	//wrap5
	$("#container5").sliphover({
		withLink:false //링크 속성 해제
	});// #container5 △
	
});//end