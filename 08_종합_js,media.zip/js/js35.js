$(document).ready(function(){
    //wrap
    
    var n = 1;
    
    function change(){
        $("#container:not(:animated)").animate({left:(n-1)*-300});
        $("#btn_wrap button").removeClass("active");
        $(".btn"+n).addClass("active");
    }
    
    $(".prev").click(function(){ //<
        n--;
        //console.log(n);
        if(n==0){
            $("#container").css("left",-1500);
            n = 5;
        }
        change();
    });
    
    $(".next").click(function(){ //>
        n++;
        //console.log(n);
        if(n==7){
            $("#container").css("left",0);
            n = 2;
        }
        change();
    });
    
    $(".btn").click(function(){ //>
        n = $(this).attr("data-n");
        change();
    });
    
    
    
    
    
});