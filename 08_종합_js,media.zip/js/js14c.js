$(document).ready(function(){
    //wrap
    $("#wrap dl dd:not(:first)").hide(); 
    $("#wrap dl dt:first a").addClass("selected1");
    
    $("#wrap dl dt a").click(function(){
        $("#wrap dl dt a").removeClass("selected1");
        $(this).addClass("selected1");
        $(".star_wrap img").attr("src","images/star1.png");
        $("#wrap dl dd:not(:animated)").slideUp();
        $(this).parent().next().slideDown(); //클릭한 a의 부모 dt다음에 있는 dd
    });
    
    $(".star_wrap img").click(function(){
        $(".star_wrap img").attr("src","images/star1.png");
        $(this).attr("src","images/star2.png");
        $(this).prevAll("img").attr("src","images/star2.png");
    });
    
    
    
    
    
    
    
    
    
    
    
    
});