$(document).ready(function(){
	//ex1
	var show_img1 = setInterval(function(){
		$(".img1")
				.fadeIn(2000)
				.fadeOut(4000);
	},3000);
	
	//ex2
	var show_txt = setTimeout(function(){
		$("#ex2_t p:eq(0)").animate({marginLeft:"0px"},500);
		$("#ex2_t p:eq(1)").animate({marginLeft:"0px"},1000);
		$("#ex2_t p:eq(2)").animate({marginLeft:"0px"},1500);
		$("#ex2_t p:eq(3)").animate({marginLeft:"0px"},2000);
		$("#ex2_t p:eq(4)").animate({marginLeft:"0px"},2500);
	},1000)
	
	//ex3
	var show_ex3 = setInterval(function(){
		$(".ex3_i").delay(1000).animate({marginLeft:"-500px"},"slow");
		$(".ex3_i").delay(1000).animate({marginLeft:"-1000px"},"slow");
		$(".ex3_i").delay(1000).animate({marginLeft:"-1500px"},"slow");
		$(".ex3_i").delay(1000).animate({marginLeft:"-2000px"},"slow");
		$(".ex3_i").delay(1000).animate({marginLeft:"-1500px"},"slow");
		$(".ex3_i").delay(1000).animate({marginLeft:"-1000px"},"slow");
		$(".ex3_i").delay(1000).animate({marginLeft:"-500px"},"slow");
		$(".ex3_i").delay(1000).animate({marginLeft:"0px"},"slow");
	},300)
	
	//ex4
	var show_ex4 = setInterval(function(){
		$(".ex4_i").delay(1000).animate({marginTop:"-280px"},"slow");
		$(".ex4_i").delay(1000).animate({marginTop:"-560px"},"slow");
		$(".ex4_i").delay(1000).animate({marginTop:"-840px"},"slow");
		$(".ex4_i").delay(1000).animate({marginTop:"-1120px"},"slow");
		$(".ex4_i").delay(1000).animate({marginTop:"-840px"},"slow");
		$(".ex4_i").delay(1000).animate({marginTop:"-560px"},"slow");
		$(".ex4_i").delay(1000).animate({marginTop:"-280px"},"slow");
		$(".ex4_i").delay(1000).animate({marginTop:"0px"},"slow");
	},300)
	
	//ex5
		var show_ex4 = setInterval(function(){
		$(".ex5_i").delay(1000).animate({marginLeft:"-564px"},"slow");
		$(".ex5_i").delay(2000).animate({marginLeft:"-1128px"},"slow");
		$(".ex5_i").delay(3000).animate({marginLeft:"-564px"},"slow");
		$(".ex5_i").delay(4000).animate({marginLeft:"0px"},"slow");
	},3000)
	
	//ex6
		banner6();
		function banner6(){
			$("#ba0").delay(2500).animate({left:"-500px"});
			$("#ba1").delay(2500).css({display:"block",left:"500px"})
							.animate({left:"0"},function(){
							$(this).delay(2500).animate({left:"-500px"})
			});
			$("#ba2").delay(2500).css({display:"block",left:"500px"})
							.animate({left:"0"},function(){
							$(this).delay(2500).animate({left:"-500px"})
			});
			$("#ba0").delay(2500).css({display:"block",left:"500px"})
							.animate({left:"0"},banner6);//콜백함수 반복.
		}
	
	//ex7
		banner7();
		function banner7(){
			$("#ba3").delay(2500).animate({top:"-2800px"});
			$("#ba4").delay(2500).css({display:"block",top:"280px"})
							.animate({top:"0"},function(){
							$(this).delay(2500).animate({top:"-280px"})
			});
			$("#ba5").delay(2500).css({display:"block",top:"280px"})
							.animate({top:"0"},function(){
							$(this).delay(2500).animate({top:"-280px"})
			});
			$("#ba3").delay(2500).css({display:"block",top:"280px"})
							.animate({top:"0"},banner7);//콜백함수 반복.
		}
		
	//ex8
		var banner8 = setInterval(function(){
			$("#ex8 ul li:first").slideUp(function(){
				$(this).appendTo($("#ex8 ul")).slideDown();
			})
		},5000);
	
	
	
	
	
	
	
	
});//end

