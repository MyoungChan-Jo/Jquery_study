$(document).ready(function(){
	//ex1
	$("#ex1_i li a").css({marginTop:"-100px"});
	$("#ex1_i li a").hover(function(){
		$(this).stop().animate({marginTop:"-30px"}, 300, "easeOutBounce");
	},function(){
		$(this).stop().animate({marginTop:"-100px"}, 300, "easeOutBounce");
	});
});//end

//ex2
var ex2 = setInterval(function(){
	$(".ex2_i img").animate({top:"-20px"}, 1000);
	$(".ex2_i img").animate({top:"0px"}, 1000);
},2000);

//ex3
var ex3 = setInterval(function(){
	$(".ex3_i img").delay(300).animate({top:"50px"},1000, "easeOutBounce");
	$(".ex3_i img").delay(2000).animate({top:"0px"},2000, "easeOutBounce");
}, 3000)
