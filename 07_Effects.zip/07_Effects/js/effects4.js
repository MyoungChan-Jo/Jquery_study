$(document).ready(function(){
	$(".list_li2 div").hide();
	$(".list_li2").toggle(function(){
		$(".list_li2 div:not(:animated)").slideDown();
		$("#list_li2a").addClass("sel")
		$(".list_li2 span").text("-")
	},function(){
		$(".list_li2 div:not(:animated)").slideUp();
		$("#list_li2a").removeClass("sel")
		$(".list_li2 span").text("+")
	});
});