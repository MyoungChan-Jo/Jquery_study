$(document).ready(function(){
	/*
	$("selector").animate({style},speed,easing,callback)
	$("selector").stop() 진행중인 애니메이션을 바로 멈추게 함
	$("selector").finish() 애니메이션을 실행하고 멈춤.
	https://jqueryui.com/download/all/
	*/
	//ex1
	$("#ex1").hover(function(){
		$(this).css({animationPlayState:"paused"});
	},function(){
		$(this).css({animationPlayState:"running"});
	});
	
	//ex2
	$(".ex2_1")
		.animate({left:"60%"},1000)
		.animate({top:"40%"},500)
		.animate({left:"0%"},1000)
		.animate({top:"0%"},500);
	
	//ex3
	$(".ex3_1").click(function(){
		$(this)
			.delay(1000)
			.animate({left:"40%", opacity:"0.5"},2000)
			.animate({left:"+=100px"},1000)
			.animate({top:"+=150px"},2000)
			.animate({top:"-=50px"},"fast")
			.slideUp(1000)
			.slideDown(1500)
			.animate({left:"0", opacity:"1"},1000)
	})
	
	//ex4
	function ani4(){
		$(".ex4_i img").animate({width:"100"})
		$(".ex4_i img").animate({width:"200"})
		$(".ex4_i img").animate({width:"50"})
		$(".ex4_i img").animate({width:"500"})
	}
	$(".btn4").click(ani4);
	
	//ex5
	$(".btn5_1").click(function(){
		$(".ex5_i img:not(:animated)").css({top:"0", left:"0"}).animate({left:"+=500"},2000)
	});
	$(".btn5_2").click(function(){
		$(".ex5_i img").stop();
		
	});
	
	//ex6
	$(".btn6_1").click(function(){
		$(".ex6_i img:not(:animated)").css({left:"0", top:"10px"}).animate({left: "+=800px"},2000)
	});
	$(".btn6_2").click(function(){
		$(".ex6_i img").stop();
	});
	$(".btn6_3").click(function(){
		$(".ex6_i img").finish();
	});
	
	
	
	
	
});//end