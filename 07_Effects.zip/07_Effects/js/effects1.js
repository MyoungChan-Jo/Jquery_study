$(document).ready(function(){
	/*
	EFFECTS
	1.$("selector").show(speed,easing,callback) selector 보이기(visibility:hidden x)
	2.$("selector").hide(speed,easing,callback) selector 숨기기(visibility,)
	3.$("selector").toggle(speed,easing,callback) selector show/hide
	speed: slow(600) normal(400) fast(200)
	easing(효과): ui 파일을 연결해서 적용을 해야 한다. swing(default)
	callback: 애니메이션이 끝난 후 콜백 함수가 실행. 효과가 100%완료후에 작동.
	*/
	
	//ex1
	$(".btn1").click(function(){//show
		$(".box").show();
	});
	$(".btn2").click(function(){//hide
		$(".box").hide();
	});
	$(".btn3").click(function(){//toggle
		$(".box").toggle();
	});
	$(".btn4").click(function(){//toggle
		$(".box:not(:animated)").toggle("slow");
	});
	$(".btn5").click(function(){//callback
		$(".box").show(1000, function(){
			alert ("HEOLLO")
		})
	})
	/*
	$("selector":not(:animated)): 애니메이션 효과가 아닌 선택자. 애니메이션이 모두 끝나야 실행한다.
	*/
	
	
});//end