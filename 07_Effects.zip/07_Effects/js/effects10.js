$(document).ready(function(){
	//event_wrap1
	var showEvent = false;
	$("#btn_top_event").click(function(){
		showEvent = !showEvent;
		if(showEvent){
			$("#main_header_wrap").animate({top:"90px"},500,"easeOutBounce");
			$("#btn_top_event").children("img").attr({src:"images/btn_event_hide.png"});
		}else{
			$("#main_header_wrap").animate({top:"0"},500,"easeOutBounce");
			$("#btn_top_event").children("img").attr({src:"images/btn_event_show.png"});
		}
	});
	
	//event_wrap1
	var show1 = false;
	$("#btn").click(function(){
		show1 = !show1;
		if(show1){
			$("#event_con").animate({height:"350px"},500,"easeOutBounce")
			$("#btn img").attr({src:"images/icon1.png"});
		}else{
			$("#event_con").animate({height:"0"},500,"easeOutBounce")
			$("#btn img").attr({src:"images/icon2.png"});
		}
	})
	
	
	
	
});//end