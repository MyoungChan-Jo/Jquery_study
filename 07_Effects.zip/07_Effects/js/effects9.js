$(document).ready(function(){
	//ex1
	$("#ex1").mouseover(function(){
		$(".ex1_i:not(:animated)").animate({marginLeft:"-228px"},1000,"easeOutBounce");
	}).mouseout(function(){
		$(".ex1_i:not(:animated)").animate({marginLeft:"0"},1000,"easeOutBounce");
	})
	

	//ex2
$("#ex2").mouseover(function(){
	$(".ex2_i:not(:animated)").animate({marginTop:"-179px"},"fast");
}).mouseout(function(){
	$(".ex2_i:not(:animated)").animate({marginTop:"0"},"fast");
});

	//ex3
	$(".img3_2").css({left:"-228px",top:"0"});
	$("#ex3").mouseover(function(){
		$(".img3_2").stop().animate({left:"0", rightl:"228px"});
	}).mouseout(function(){
		$(".img3_2").stop().animate({left:"-228px", rightl:"0"});
	});
	
	//ex4
	$(".img4_2").css({left:"0",top:"-179px"});
	$("#ex4").mouseover(function(){
		$(".img4_2").stop().animate({top:"0"},300);
	}).mouseout(function(){
		$(".img4_2").stop().animate({top:"-179"},300);
	});
	
	
	//ex5
	$(".img5_1").hover(function(){
		$(this).stop().animate({top:"-20px"}, "slow");
	},function(){
		$(this).stop().animate({top:"0px"},"slow");
	});
	$(".img5_2").hover(function(){
		$(this).stop().animate({top:"-20px"}, "slow");
	},function(){
		$(this).stop().animate({top:"0px"},"slow");
	});		
	
	//ex6
	$(".ex6_i li img").mouseover(function(){
		$(this).stop().animate({borderRadius:"50px"},500,"easeOutBounce");
	}).mouseout(function(){
		$(this).stop().animate({borderRadius:"10px"},500,"easeInElastic");
	});
	
	//ex7
	$(".ex7_i").hover(function(){
		$(".img7", this).eq(1).stop().animate({opacity:"0"},500);
	},function(){
		$(".img7", this).eq(1).stop().animate({opacity:"1"},500);
	});
	
	//ex8
	$(".ex8_i").hover(function(){
		$(this).find("img")
		.css({width:"600px", height:"370px", display:"block", left:"-50px", top:"-50px", opacity:"0"})
		.stop().animate({opacity:"1", width:"500px", height:"280px", left:"0", top:"0"},500)
	},function(){
		$(this).find("img")
		.stop()
		.fadeOut();
	});
	
	//ex9
	$(".menu9 a").after("<span class='under1'></span>");
	$(".under1").css({position:"absolute", left:"47px", top:"24px", width:"5px", height:"2px", backgroundColor:"#333333"});
	$(".menu9").mouseenter(function(){
		$(".under1:not(:animated)").animate({width:"40px", left:"30px"},"fast");
	}).mouseleave(function(){
		$(".under1:not(:animated)").animate({width:"5px", left:"47px"},"fast");
	});
	
	//ex10
	$(".menu10 a").after("<span class='under2'></span>");
	$(".under2").css({position:"absolute", left:"28px", top:"24px", width:"12px", height:"3px", backgroundColor:"#333333"});
	$(".menu10").mouseenter(function(){
		$(".under2:not(:animated)").animate({width:"42px"},"fast");
	}).mouseleave(function(){
		$(".under2:not(:animated)").animate({width:"12px"},"fast");
	});
	
	
	
});//end