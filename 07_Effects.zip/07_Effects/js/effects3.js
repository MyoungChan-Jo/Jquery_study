$(document).ready(function(){
	/*
	$("selector").slideUp(speed,easing,callback) selector 아래에서 위로 올려 표시
	$("selector").slideDown(speed,easing,callback) selector 위에서 아래로 내려 비표시
	$("selector").slideToggle(speed,easing,callback) selector  Up/Down 번갈아가면서
	*/
	
	$(".btn1").click(function(){//slideUp
		$("#photo").slideUp(1000);
	});
	$(".btn2").click(function(){//slideUp
		$("#photo").slideUp(1000, function(){
			$(this).slideDown(1000);
		});
	});
	$(".btn3").click(function(){//slideDown
		$("#photo").slideDown(1000);
	});
	$(".btn4").click(function(){//slideToggle
		$("#photo").slideToggle(1000);
	});
	$(".btn5").click(function(){//slideToggle
		$("#photo:not(:animated)").slideToggle(1000);
	});
	$("#ex2").click(function(){
		//$("#ex2_con").slideDown(3000);
		//$("#ex2_con").slideUp(3000);
		$("#ex2_con").slideToggle(1000);
	});
});