$(document).ready(function(){
	//ex1
	$(".btn1").click(function(){
		var easing = $(this).attr("data-easing");
		$(".ex1_1")
			.animate({left:"800px"},500, easing)
			.animate({top:"100px"},500, easing)
			.animate({left:"0"},500, easing)
			.animate({top:"0"},500, easing);
		$(".ex1_2:not(:animated)").slideUp(1000, easing, function(){
			$(this).slideDown(1000);
		});
	}); 
	
	//ex2
	$(".btn2").toggle(function(){
		$(".ex2_t").animate({fontSize:"50px"}, 1500, "easeInOutElastic")
	},function(){
		$(".ex2_t").animate({fontSize:"20px"}, 1500, "easeInOutElastic")
	});
	
	//ex3
	$(".btn3_1").click(function(){
		$("#ex3_i ul li img").toggle(200, "easeOutBounce")
	});
	$(".btn3_2").click(function(){
		$("#ex3_i ul li img").toggle(500, "easeInBounce")
	});
	
	//ex4
	$(".ex4_t li").hover(function(){
		var bg1 = $(this).attr("data-bg");
		$(this).animate({backgroundColor:bg1}, 800);
	},function(){
		$(this).animate({backgroundColor:"#ccccff"}, 800)
	});
	
	//ex5
	$(".ex5_t")//ui JQUERY있어야 가능하다.
		.animate({height:"300px", opacity:"0.4", lineHeight:"300px"}, "slow")
		.animate({width:"300px", opacity:"0.8"}, "slow")
		.animate({height:"100px", opacity:"0.5", lineHeight:"100px"}, "slow")
		.animate({fontSize:"30px", backgroundColor:"red", opacity:"1.0", color:"#ffffff"}, "slow")
	
	//ex6
	/*
	$("selector").animate({styles},{options})1.duration:속도,지속시간 | 2.complete:애니메이션 완료 후 실행할 함수 | 3.step:애니메이션의 각 단계에 대해 실행할 함수... 등등.
	*/
	$(".btn6").click(function(){
		$(".ex6_t")
			.animate({width:"150px", height:"150px"},{
			duration : 2000, easing : "linear", complete : function(){
				$(this).after("<p>Hello~!!</p>")
			}
		})
	});
	
	//ex7
	$(".ex7_1 p, .ex7_2").text("");
	$(".btn7").click(function(){
		$(".ex7_1 p").animate({width:"400px"},{
			duration:5000,
			easing:"linear",
			step:function(x){
				//$(".ex7_2").text(x);
				$(".ex7_2").text(Math.round(x*100/400) + "%")
			}
		});
	});
	
	//ex8
	$(".ex8_t")
		.animate({left:"60%", borderRadius:"0%"}, "9000", "easeOutQuint")
		.animate({height:"300px", opacity:"0.5"}, "slow", "easeOutQuint")
		.animate({width:"300px", opacity:"0.5", borderRadius:"50%"}, "normal", "easeOutQuint")
		.animate({width:"90", opacity:"1", borderRadius:"0%"}, "fast", "easeOutQuint")
		.animate({height:"90"}, 1000, "easeOutQuint")
		.animate({left:"0", borderRadius:"50%"}, 1000, "easeOutQuint");
	
	//ex9
	function loop(){
		$(".ex9_t")
			.animate({left:"70%"},1000,"easeOutQuint")
			.animate({left:"0%"},1000,"easeOutQuint",loop)
	}
	$(".btn9_1").click(function(){ loop();} )
	$(".btn9_2").click(function(){
		$(".ex9_t").stop(loop);
	});
	
	//ex10
	function time(){
		$(".ex10_t")
			.animate({left:"+=200"},500,"easeInBounce")
			.animate({left:"-=50"},500,"easeInBounce")
	}
	$(".btn10").click(function(){
		setTimeout(time, 1000);
	});
	
	//ex11
	$(".btn11").click(function(){
		$(".ex11_t")
			.animate({left:"85%"}, 1000, "easeOutQuint", function(){
			alert("도착!!");
		})
	});
	
	//ex12
	$("#ex12 p").text("");
	$("#ex12").mouseenter(function(){
		$("#ex12 p:eq(0)").animate({width:"100%"},600)
		$("#ex12 p:eq(1)").animate({height:"100%"},600)
		$("#ex12 p:eq(2)").animate({width:"100%"},600)
		$("#ex12 p:eq(3)").animate({height:"100%"},600)
	});
	/*
	$("#ex12").mouseenter(function(){
		$("#ex12 p:eq(0)").animate({width:"100%"},600,function(){
			$(this).next().animate({height:"100%"},600,funtion(){
				$(this).next().animate({width:"100%"},600,function(){
					$(this).next().animate({height:"100%"},600);
					});
				});
			});
		});
	*/
	
	//ex13
	$("#ex13 p").text("");
	$("#ex13 p:nth-child(1)").delay(1000).animate({width:"100%"},"800", function(){
		$("#ex13 p:nth-child(2)").animate({height:"100%"},"800", function(){
			$("#ex13 p:nth-child(3)").animate({width:"100%"},"800", function(){
				$("#ex13 p:nth-child(4)").animate({height:"100%"},"800")
			});
		});
	});
	
	//ex14
	$(".ex14_t p").text("");
	$(".ex14_t p").delay(1000).animate({width:"100%"},"800");
	
});//end