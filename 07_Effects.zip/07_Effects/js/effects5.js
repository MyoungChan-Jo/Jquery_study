$(document).ready(function(){
	/*
	$("selector").fadeIn(speed,easing,callback) opacity 0~1전환하면서 서서히 나타남
	$("selector").fadeOut(speed,easing,callback) opacity 0~1전환하면서 서서히 사라짐
	$("selector").fadeTo.fadeTo(speed,easing,callback,opacity) 불투명도 지정(0.0)~(1.0) 0=fadeIn
	$("selector").fadeToggle(speed,easing,callback) fadeIn+fadeOut
	$("selector").delay(speed) 대기시간, 지연시간
	*/
	
	$(".photo").hide();
	$(".btn1").click(function(){//fadeIn
		//$(".photo").fadeIn(1000);
		$(".photo").fadeIn(1000, function(){
			$(this).fadeOut(1500);
		});
	});
	$(".btn2").click(function(){//fadeOut
		$(".box1, .box2, .box3").fadeOut("slow");
	});
	$(".btn3").click(function(){//fadeTo
		$(".photo").fadeTo("slow", 0.4);
	});
	$(".btn4").click(function(){//fadeTo
		$(".photo").fadeTo("slow", 0.7);
	});
	$(".btn5").click(function(){//fadeToggle
		$(".photo").fadeToggle(1000);
	});
	$(".btn6").click(function(){//fadeToggle
		$(".photo:not(:animated)").fadeToggle(1000);
	});
	
	$("#pwd").focus(function(){
		//$(".pwd_txt").fadeIn().fadeOut(5000);
		$(".pwd_txt").show().fadeOut(5000);
	});
	
	/*ex2*/
	$(".ex2_1").click(function(){
		//첫번째 이미지 복제후 숨김> 이미지 끝에 서서히 나타나기
		$("#img2_i img:first").clone().hide().appendTo($("#img2_i")).fadeIn(1000);
	});
	
	/*ex3*/
	$("#ex3 p").text("").hide();
	//$(".ex3_1").fadeIn(1000);
	//$(".ex3_2").fadeIn(3000);
	//$(".ex3_3").fadeIn(4000);
	$(".ex3_1").delay("slow").fadeIn();
	$(".ex3_2").delay(2000).fadeIn(); 
	$(".ex3_3").delay(4000).fadeIn();
	
	/*ex4*/
	$("#ex4 p").text("").hide();
	$(".ex4_1").delay("slow").fadeIn();
	$(".ex4_2").delay(2000).fadeIn();
	$(".ex4_3").delay(4000).fadeIn();
	$(".ex4_4").delay(6000).fadeIn();
	
	/*ex5*/
	$(".ex5_i").mouseover(function(){
		$(".out1",this).fadeOut();
	});
	$(".ex5_i").mouseout(function(){
		$(".out1").fadeIn();
	})
		
});//end