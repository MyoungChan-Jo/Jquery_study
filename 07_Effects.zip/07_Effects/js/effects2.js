$(document).ready(function(){
	$("#btn li:first").addClass("selected");
	$("#btn li").click(function(){
		$("#btn li").removeClass("selected");
		$(this).addClass("selected");
	});
	
	$("#btn li").eq(0).click(function(){//ALL
		$("#photo p").show();
	});
	$("#btn li").eq(1).click(function(){//상품1
		$("#photo p").hide();
		$(".photo1").show();
	});
	$("#btn li").eq(2).click(function(){//상품2
		$("#photo p").hide();
		$(".photo2").show();
	});
	$("#btn li").eq(3).click(function(){//상품3
		$("#photo p").hide();
		$(".photo3").show();
	});

});
